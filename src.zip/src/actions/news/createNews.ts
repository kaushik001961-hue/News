"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { auth } from "@/lib/auth";

interface CreateNewsInput {
  title: string;
  slug: string;
  excerpt: string;
  content: string;

  categoryId?: string;
  reporterId?: string;

  featuredImage?: string;
  videoUrl?: string;

  featured: boolean;
  breaking: boolean;
  trending: boolean;

  status: string;

  seoTitle?: string;
  seoDescription?: string;
  keywords?: string;

  tags: string[];
}

export async function createNews(data: CreateNewsInput) {
  const session = await auth();

  if (!session?.user?.id) {
    throw new Error("Unauthorized");
  }

  const post = await prisma.post.create({
    data: {
      title: data.title,
      slug: data.slug,
      excerpt: data.excerpt,
      content: data.content,

      categoryId: data.categoryId || null,
      reporterId: data.reporterId || null,

      featuredImage: data.featuredImage,
      videoUrl: data.videoUrl,

      featured: data.featured,
      breaking: data.breaking,
      trending: data.trending,

      status: data.status,

      seoTitle: data.seoTitle,
      seoDescription: data.seoDescription,
      seoKeywords: data.keywords,

      authorId: session.user.id,
    },
  });

  if (data.tags.length) {
    for (const tag of data.tags) {
      let tagRecord = await prisma.tag.findUnique({
        where: { name: tag },
      });

      if (!tagRecord) {
        tagRecord = await prisma.tag.create({
          data: {
            name: tag,
            slug: tag
              .toLowerCase()
              .replace(/\s+/g, "-"),
          },
        });
      }

      await prisma.postTag.create({
        data: {
          postId: post.id,
          tagId: tagRecord.id,
        },
      });
    }
  }

  revalidatePath("/admin/news");
  revalidatePath("/");

  redirect("/admin/news");
}