"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

export async function publishNews(id: string) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  const role = session.user.role;

  if (role !== "EDITOR" && role !== "ADMIN") {
    throw new Error("Permission denied");
  }

  const updateData: any = {
    status: "PUBLISHED",
    publishedAt: new Date(),
  };

  if (role === "EDITOR") {
    updateData.reviewedById = session.user.id;
    updateData.reviewedAt = new Date();
    updateData.assignedEditorId = session.user.id;
  }

  if (role === "ADMIN") {
    updateData.approvedById = session.user.id;
    updateData.reviewedById = session.user.id;
    updateData.reviewedAt = new Date();
  }

  await prisma.post.update({
    where: {
      id,
    },
    data: updateData,
  });

  revalidatePath("/");

  revalidatePath("/admin/news");
  revalidatePath("/editor/news");
  revalidatePath("/reporter/news");
}