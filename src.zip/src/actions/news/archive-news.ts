"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

export async function archiveNews(id: string) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  await prisma.post.update({
    where: {
      id,
    },

    data: {
      status: "ARCHIVED",
    },
  });

  revalidatePath("/admin/news");

  revalidatePath("/editor/news");

  return {
    success: true,
  };
}