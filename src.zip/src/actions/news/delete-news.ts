"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

export async function deleteNews(id: string) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  if (
    session.user.role !== "ADMIN" &&
    session.user.role !== "EDITOR"
  ) {
    throw new Error("Permission denied");
  }

  // Remove tag relations first
  await prisma.post.update({
    where: {
      id,
    },
    data: {
      tags: {
        set: [],
      },
    },
  });

  // Delete comments
  await prisma.comment.deleteMany({
    where: {
      postId: id,
    },
  });

  // Delete activities
  await prisma.postActivity.deleteMany({
    where: {
      postId: id,
    },
  });

  // Delete versions
  await prisma.postVersion.deleteMany({
    where: {
      postId: id,
    },
  });

  // Delete post
  await prisma.post.delete({
    where: {
      id,
    },
  });

  revalidatePath("/");

  revalidatePath("/admin/news");
  revalidatePath("/editor/news");
  revalidatePath("/reporter/news");
}