"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

interface DuplicateNewsInput {
  id: string;
}

export async function duplicateNews({
  id,
}: DuplicateNewsInput) {
  const session = await auth();

  if (!session?.user?.id) {
    throw new Error("Unauthorized");
  }

  const post = await prisma.post.findUnique({
    where: {
      id,
    },
    include: {
      tags: {
        include: {
          tag: true,
        },
      },
    },
  });

  if (!post) {
    throw new Error("News not found");
  }

  const duplicate = await prisma.$transaction(async (tx) => {
    const newPost = await tx.post.create({
      data: {
        title: `${post.title} (Copy)`,

        slug: `${post.slug}-copy-${Date.now()}`,

        excerpt: post.excerpt,

        content: post.content,

        categoryId: post.categoryId,

        reporterId: post.reporterId,

        featuredImage: post.featuredImage,

        videoUrl: post.videoUrl,

        featured: false,

        breaking: false,

        trending: false,

        status: "DRAFT",

        seoTitle: post.seoTitle,

        seoDescription: post.seoDescription,

        seoKeywords: post.seoKeywords,

        authorId: session.user.id,
      },
    });

    for (const item of post.tags) {
      await tx.postTag.create({
        data: {
          postId: newPost.id,
          tagId: item.tagId,
        },
      });
    }

    return newPost;
  });

  revalidatePath("/admin/news");
  revalidatePath("/editor/news");
  revalidatePath("/reporter/news");

  return {
    success: true,
    id: duplicate.id,
  };
}