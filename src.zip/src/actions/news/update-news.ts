"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export interface UpdateNewsInput {
  id: string;

  title: string;
  slug: string;

  excerpt?: string;
  content: string;

  categoryId?: string;
  reporterId?: string;

  featuredImage?: string;
  videoUrl?: string;

  featured: boolean;
  breaking: boolean;
  trending: boolean;

  seoTitle?: string;
  seoDescription?: string;
  keywords?: string;
  canonicalUrl?: string;

  status: string;
}

export async function updateNews(
  values: UpdateNewsInput
) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  const role = session.user.role;

  // Check if news exists
  const existing = await prisma.post.findUnique({
    where: {
      id: values.id,
    },
  });

  if (!existing) {
    throw new Error("News not found.");
  }

  // Reporter can edit only own news
  if (
    role === "REPORTER" &&
    existing.authorId !== session.user.id
  ) {
    throw new Error("Unauthorized");
  }

  const data: any = {
    title: values.title,
    slug: values.slug,

    excerpt: values.excerpt,
    content: values.content,

    image: values.featuredImage || null,
    video: values.videoUrl || null,

    categoryId: values.categoryId || null,

    featured: values.featured,
    breaking: values.breaking,
    trending: values.trending,

    seoTitle: values.seoTitle || null,
    seoDescription: values.seoDescription || null,
    seoKeywords: values.keywords || null,
    canonicalUrl: values.canonicalUrl || null,
  };

  // =============================
  // REPORTER
  // =============================
  if (role === "REPORTER") {
    // Reporter cannot publish
    data.status = "PENDING";
    data.submittedAt = new Date();
  }

  // =============================
  // EDITOR
  // =============================
  if (role === "EDITOR") {
    data.status = values.status;

    data.assignedEditorId = session.user.id;

    if (values.reporterId) {
      data.assignedReporterId =
        values.reporterId;
    }

    data.reviewedById = session.user.id;
    data.reviewedAt = new Date();
  }

  // =============================
  // ADMIN
  // =============================
  if (role === "ADMIN") {
    data.status = values.status;

    if (values.reporterId) {
      data.assignedReporterId =
        values.reporterId;
    }

    data.approvedById = session.user.id;
  }

  await prisma.post.update({
    where: {
      id: values.id,
    },
    data,
  });

  revalidatePath("/");

  revalidatePath("/admin/news");
  revalidatePath("/editor/news");
  revalidatePath("/reporter/news");

  switch (role) {
    case "ADMIN":
      redirect("/admin/news");

    case "EDITOR":
      redirect("/editor/news");

    case "REPORTER":
      redirect("/reporter/news");
  }
}