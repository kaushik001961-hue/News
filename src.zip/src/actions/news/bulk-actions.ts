"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

export type BulkNewsAction =
  | "DELETE"
  | "PUBLISH"
  | "UNPUBLISH"
  | "FEATURE"
  | "UNFEATURE"
  | "BREAKING"
  | "UNBREAKING"
  | "TRENDING"
  | "UNTRENDING";

export async function bulkNewsAction(
  ids: string[],
  action: BulkNewsAction
) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  if (
    session.user.role !== "ADMIN" &&
    session.user.role !== "EDITOR"
  ) {
    throw new Error("Permission denied");
  }

  switch (action) {
    case "PUBLISH":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          status: "PUBLISHED",
          publishedAt: new Date(),
        },
      });
      break;

    case "UNPUBLISH":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          status: "DRAFT",
          publishedAt: null,
        },
      });
      break;

    case "FEATURE":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          featured: true,
        },
      });
      break;

    case "UNFEATURE":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          featured: false,
        },
      });
      break;

    case "BREAKING":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          breaking: true,
        },
      });
      break;

    case "UNBREAKING":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          breaking: false,
        },
      });
      break;

    case "TRENDING":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          trending: true,
        },
      });
      break;

    case "UNTRENDING":
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {
          trending: false,
        },
      });
      break;

    case "DELETE":
      // Remove tag relationships
      await prisma.post.updateMany({
        where: {
          id: {
            in: ids,
          },
        },
        data: {}
      });

      await prisma.comment.deleteMany({
        where: {
          postId: {
            in: ids,
          },
        },
      });

      await prisma.postActivity.deleteMany({
        where: {
          postId: {
            in: ids,
          },
        },
      });

      await prisma.postVersion.deleteMany({
        where: {
          postId: {
            in: ids,
          },
        },
      });

      await prisma.post.deleteMany({
        where: {
          id: {
            in: ids,
          },
        },
      });

      break;
  }

  revalidatePath("/");

  revalidatePath("/admin/news");
  revalidatePath("/editor/news");
  revalidatePath("/reporter/news");
}