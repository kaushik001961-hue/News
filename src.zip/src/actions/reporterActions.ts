"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import {
  ReporterStatus,
  ReporterActivityType,
} from "@prisma/client";

import { logReporterActivity } from "@/lib/reporterActivity";

// =====================================================
// UPDATE REPORTER
// =====================================================

export async function updateReporter(
  id: string,
  data: Record<string, unknown>
) {
  await prisma.reporter.update({
    where: { id },
    data,
  });

  await logReporterActivity({
    reporterId: id,
    action: ReporterActivityType.PROFILE_UPDATED,
    title: "Profile Updated",
    description: "Reporter profile updated.",
    performedBy: "Admin",
  });

  revalidatePath("/admin/reporters");
  revalidatePath(`/admin/reporters/${id}`);
  revalidatePath(`/admin/reporters/${id}/edit`);
}

// =====================================================
// APPROVE
// =====================================================

export async function approveReporter(id: string) {
  await prisma.reporter.update({
    where: { id },
    data: {
      status: ReporterStatus.APPROVED,
      active: true,
      verified: true,
      approvedAt: new Date(),
    },
  });

  await logReporterActivity({
    reporterId: id,
    action: ReporterActivityType.APPROVED,
    title: "Reporter Approved",
    description: "Reporter application approved.",
    performedBy: "Admin",
  });

  revalidatePath("/admin/reporters");
}

// =====================================================
// REJECT
// =====================================================

export async function rejectReporter(
  id: string,
  reason: string
) {
  await prisma.reporter.update({
    where: { id },
    data: {
      status: ReporterStatus.REJECTED,
      remarks: reason,
      rejectedAt: new Date(),
      active: false,
    },
  });

  await logReporterActivity({
    reporterId: id,
    action: ReporterActivityType.REJECTED,
    title: "Application Rejected",
    description: reason,
    performedBy: "Admin",
  });

  revalidatePath("/admin/reporters");
}

// =====================================================
// BLOCK
// =====================================================

export async function suspendReporter(id: string) {
  await prisma.reporter.update({
    where: { id },
    data: {
      status: ReporterStatus.SUSPENDED,
      active: false,
      blockedAt: new Date(),
    },
  });

  await logReporterActivity({
  reporterId: id,
  action: ReporterActivityType.BLOCKED,
  title: "Reporter Suspended",
  description: "Reporter account suspended.",
  performedBy: "Admin",
});

  revalidatePath("/admin/reporters");
}

// =====================================================
// DELETE
// =====================================================

export async function deleteReporter(id: string) {
  await prisma.reporter.delete({
    where: { id },
  });

  revalidatePath("/admin/reporters");
}