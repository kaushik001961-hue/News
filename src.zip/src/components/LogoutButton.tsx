"use client";

import { LogOut } from "lucide-react";
import { signOut } from "next-auth/react";

export default function LogoutButton() {
  return (
    <button
      onClick={() =>
        signOut({
          callbackUrl: "/login",
        })
      }
      className="flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-4 py-3 font-medium text-white transition-all duration-200 hover:bg-red-700 hover:shadow-lg"
    >
      <LogOut size={18} />

      <span>Logout</span>
    </button>
  );
}