"use client";

import Image from "next/image";
import Link from "next/link";

import {
  Eye,
  Pencil,
  Trash2,
  MoreVertical,
  Star,
  Flame,
} from "lucide-react";

import NewsStatusBadge from "./NewsStatusBadge";
import type { NewsItem } from "./NewsTable";

interface NewsRowProps {
  article: NewsItem;
  selected: boolean;
  onToggle: () => void;
}

export default function NewsRow({
  article,
  selected,
  onToggle,
}: NewsRowProps) {
  return (
    <tr className="border-t border-slate-100 transition hover:bg-slate-50">

      {/* Checkbox */}

      <td className="px-6 py-5">

        <input
          type="checkbox"
          checked={selected}
          onChange={onToggle}
          className="h-4 w-4 rounded border-slate-300"
        />

      </td>

      {/* News */}

      <td className="px-6 py-5">

        <div className="flex items-center gap-4">

          <div className="relative h-16 w-24 overflow-hidden rounded-xl bg-slate-200">

            <Image
              src={
                article.featuredImage ||
                "/images/news-placeholder.jpg"
              }
              alt={article.title}
              fill
              className="object-cover"
            />

          </div>

          <div className="min-w-0">

            <h3 className="line-clamp-2 font-semibold text-slate-900">
              {article.title}
            </h3>

            <p className="mt-1 text-xs text-slate-500">
              /{article.slug}
            </p>

            <div className="mt-3 flex flex-wrap gap-2">

              {article.featured && (
                <span className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-700">
                  <Star size={12} />
                  Featured
                </span>
              )}

              {article.breaking && (
                <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-1 text-xs font-semibold text-red-700">
                  <Flame size={12} />
                  Breaking
                </span>
              )}

            </div>

          </div>

        </div>

      </td>

      {/* Category */}

      <td className="px-6 py-5">

        <span className="rounded-full bg-indigo-100 px-3 py-1 text-xs font-semibold text-indigo-700">
          {article.category.name}
        </span>

      </td>

      {/* Reporter */}

      <td className="px-6 py-5">

        {article.reporter ? (
          <div>

            <p className="font-medium text-slate-900">
              {article.reporter.firstName}{" "}
              {article.reporter.lastName}
            </p>

          </div>
        ) : (
          <span className="text-slate-400">
            —
          </span>
        )}

      </td>

      {/* Views */}

      <td className="px-6 py-5 font-semibold">
        {article.views.toLocaleString()}
      </td>

      {/* Status */}

      <td className="px-6 py-5">

        <NewsStatusBadge
          status={article.status}
          featured={article.featured}
          breaking={article.breaking}
        />

      </td>

      {/* Published */}

      <td className="px-6 py-5 text-sm text-slate-500">

        {article.publishedAt
          ? new Date(article.publishedAt).toLocaleDateString()
          : "-"}

      </td>

      {/* Actions */}

      <td className="px-6 py-5">

        <div className="flex justify-end gap-2">

          <Link
            href={`/editor/news/preview/${article.id}`}
            className="rounded-lg p-2 transition hover:bg-slate-100"
            title="Preview"
          >
            <Eye size={18} />
          </Link>

          <Link
            href={`/editor/news/edit/${article.id}`}
            className="rounded-lg p-2 transition hover:bg-slate-100"
            title="Edit"
          >
            <Pencil size={18} />
          </Link>

          <button
            className="rounded-lg p-2 transition hover:bg-red-100 hover:text-red-600"
            title="Delete"
          >
            <Trash2 size={18} />
          </button>

          <button
            className="rounded-lg p-2 transition hover:bg-slate-100"
            title="More"
          >
            <MoreVertical size={18} />
          </button>

        </div>

      </td>

    </tr>
  );
}