"use client";

import { useState } from "react";

import MediaCard from "./MediaCard";
import MediaPreviewDialog from "./MediaPreviewDialog";
import BulkMediaActions from "./BulkMediaActions";
import DeleteMediaDialog from "./DeleteMediaDialog";

export interface MediaItem {
  id: string;

  name: string;

  url: string;

  mimeType: string;

  size: number;

  width?: number | null;

  height?: number | null;

  folder?: string | null;

  createdAt: Date;
}

interface MediaGridProps {
  media: MediaItem[];
}

export default function MediaGrid({
  media,
}: MediaGridProps) {
  const [selectedIds, setSelectedIds] =
    useState<string[]>([]);

  const [previewMedia, setPreviewMedia] =
    useState<MediaItem | null>(null);

  const [deleteMedia, setDeleteMedia] =
    useState<MediaItem | null>(null);

  function toggleSelect(id: string) {
    setSelectedIds((current) =>
      current.includes(id)
        ? current.filter((x) => x !== id)
        : [...current, id]
    );
  }

  function clearSelection() {
    setSelectedIds([]);
  }

  if (media.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-slate-300 bg-white py-24 text-center">

        <h2 className="text-2xl font-bold text-slate-800">
          No Media Found
        </h2>

        <p className="mt-2 text-slate-500">
          Upload your first image or video.
        </p>

      </div>
    );
  }

  return (
    <>
     <BulkMediaActions
  selectedIds={selectedIds}
  clearSelection={clearSelection}
  onDelete={async (ids) => {
    console.log("Delete:", ids);
    // TODO: Call bulkDeleteMedia(ids)
  }}
  onDownload={async (ids) => {
    console.log("Download:", ids);
    // TODO: Download selected files
  }}
  onCopyUrls={async (ids) => {
    console.log("Copy URLs:", ids);
    // TODO: Copy selected URLs
  }}
  onMove={async (ids) => {
    console.log("Move:", ids);
    // TODO: Move to another folder
  }}
/>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">

        {media.map((file) => (

          <MediaCard
            key={file.id}
            media={file}
            selected={selectedIds.includes(
              file.id
            )}
            onToggle={() =>
              toggleSelect(file.id)
            }
            onPreview={() =>
              setPreviewMedia(file)
            }
            onDelete={() =>
              setDeleteMedia(file)
            }
          />

        ))}

      </div>

      <MediaPreviewDialog
        media={previewMedia}
        open={!!previewMedia}
        onClose={() =>
          setPreviewMedia(null)
        }
      />

      <DeleteMediaDialog
        media={deleteMedia}
        open={!!deleteMedia}
        onClose={() =>
          setDeleteMedia(null)
        }
      />
    </>
  );
}