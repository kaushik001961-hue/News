"use client";

export type NewsStatus =
  | "ALL"
  | "DRAFT"
  | "PENDING"
  | "PUBLISHED"
  | "REJECTED"
  | "ARCHIVED";

interface StatusFilterProps {
  value: NewsStatus;
  onChange: (status: NewsStatus) => void;
}

const statuses: {
  value: NewsStatus;
  label: string;
}[] = [
  {
    value: "ALL",
    label: "All Status",
  },
  {
    value: "DRAFT",
    label: "Draft",
  },
  {
    value: "PENDING",
    label: "Pending",
  },
  {
    value: "PUBLISHED",
    label: "Published",
  },
  {
    value: "REJECTED",
    label: "Rejected",
  },
  {
    value: "ARCHIVED",
    label: "Archived",
  },
];

export default function StatusFilter({
  value,
  onChange,
}: StatusFilterProps) {
  return (
    <select
      value={value}
      onChange={(e) =>
        onChange(e.target.value as NewsStatus)
      }
      className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium shadow-sm transition focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-100"
    >
      {statuses.map((status) => (
        <option
          key={status.value}
          value={status.value}
        >
          {status.label}
        </option>
      ))}
    </select>
  );
}