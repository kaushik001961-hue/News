"use client";

import { Download, FileSpreadsheet, FileText } from "lucide-react";

interface ExportButtonProps {
  onExportCSV: () => void;
  onExportExcel: () => void;
  onExportPDF: () => void;
}

export default function ExportButton({
  onExportCSV,
  onExportExcel,
  onExportPDF,
}: ExportButtonProps) {
  return (
    <div className="relative group">

      <button
        type="button"
        className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
      >
        <Download size={18} />
        Export
      </button>

      <div className="absolute right-0 z-50 mt-2 hidden w-56 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl group-hover:block">

        <button
          onClick={onExportCSV}
          className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-slate-100"
        >
          <FileText size={18} />
          Export CSV
        </button>

        <button
          onClick={onExportExcel}
          className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-slate-100"
        >
          <FileSpreadsheet size={18} />
          Export Excel
        </button>

        <button
          onClick={onExportPDF}
          className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-slate-100"
        >
          <FileText size={18} />
          Export PDF
        </button>

      </div>

    </div>
  );
}