"use client";

export type DateFilterValue =
  | "ALL"
  | "TODAY"
  | "YESTERDAY"
  | "LAST_7_DAYS"
  | "LAST_30_DAYS"
  | "THIS_MONTH";

interface DateFilterProps {
  value: DateFilterValue;
  onChange: (value: DateFilterValue) => void;
}

const options = [
  {
    value: "ALL",
    label: "All Dates",
  },
  {
    value: "TODAY",
    label: "Today",
  },
  {
    value: "YESTERDAY",
    label: "Yesterday",
  },
  {
    value: "LAST_7_DAYS",
    label: "Last 7 Days",
  },
  {
    value: "LAST_30_DAYS",
    label: "Last 30 Days",
  },
  {
    value: "THIS_MONTH",
    label: "This Month",
  },
] as const;

export default function DateFilter({
  value,
  onChange,
}: DateFilterProps) {
  return (
    <select
      value={value}
      onChange={(e) =>
        onChange(
          e.target.value as DateFilterValue
        )
      }
      className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium shadow-sm transition focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-100"
    >
      {options.map((option) => (
        <option
          key={option.value}
          value={option.value}
        >
          {option.label}
        </option>
      ))}
    </select>
  );
}