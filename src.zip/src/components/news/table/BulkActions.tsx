"use client";

import {
  Trash2,
  Upload,
  Star,
  Flame,
  TrendingUp,
  X,
} from "lucide-react";

interface BulkActionsProps {
  selectedCount: number;

  onPublish: () => void;

  onArchive: () => void;

  onFeature: () => void;

  onBreaking: () => void;

  onDelete: () => void;

  onClear: () => void;
}

export default function BulkActions({
  selectedCount,
  onPublish,
  onArchive,
  onFeature,
  onBreaking,
  onDelete,
  onClear,
}: BulkActionsProps) {
  if (selectedCount === 0) {
    return null;
  }

  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-blue-200 bg-blue-50 px-5 py-4">

      <div className="font-semibold text-blue-700">
        {selectedCount} article{selectedCount > 1 ? "s" : ""} selected
      </div>

      <div className="flex flex-wrap gap-2">

        <button
          onClick={onPublish}
          className="flex items-center gap-2 rounded-xl bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
        >
          <Upload size={16} />
          Publish
        </button>

        <button
          onClick={onFeature}
          className="flex items-center gap-2 rounded-xl bg-yellow-500 px-4 py-2 text-sm font-medium text-white hover:bg-yellow-600"
        >
          <Star size={16} />
          Feature
        </button>

        <button
          onClick={onBreaking}
          className="flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
        >
          <Flame size={16} />
          Breaking
        </button>

        <button
          onClick={onArchive}
          className="flex items-center gap-2 rounded-xl bg-slate-600 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700"
        >
          <TrendingUp size={16} />
          Archive
        </button>

        <button
          onClick={onDelete}
          className="flex items-center gap-2 rounded-xl bg-red-700 px-4 py-2 text-sm font-medium text-white hover:bg-red-800"
        >
          <Trash2 size={16} />
          Delete
        </button>

        <button
          onClick={onClear}
          className="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-100"
        >
          <X size={16} />
          Clear
        </button>

      </div>

    </div>
  );
}