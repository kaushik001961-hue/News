"use client";

import { RotateCcw } from "lucide-react";

interface FiltersProps {
  category: string;
  reporter: string;
  featured: string;
  breaking: string;
  trending: string;

  categories: {
    id: string;
    name: string;
  }[];

  reporters: {
    id: string;
    firstName: string;
    lastName: string;
  }[];

  onCategoryChange: (value: string) => void;
  onReporterChange: (value: string) => void;
  onFeaturedChange: (value: string) => void;
  onBreakingChange: (value: string) => void;
  onTrendingChange: (value: string) => void;

  onReset: () => void;
}

export default function Filters({
  category,
  reporter,
  featured,
  breaking,
  trending,
  categories,
  reporters,
  onCategoryChange,
  onReporterChange,
  onFeaturedChange,
  onBreakingChange,
  onTrendingChange,
  onReset,
}: FiltersProps) {
  return (
    <div className="mb-6 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">

      <div className="mb-5 flex items-center justify-between">

        <h2 className="text-lg font-bold">
          Advanced Filters
        </h2>

        <button
          onClick={onReset}
          className="flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 hover:bg-slate-100"
        >
          <RotateCcw size={16} />
          Reset
        </button>

      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">

        {/* Category */}

        <select
          value={category}
          onChange={(e) =>
            onCategoryChange(e.target.value)
          }
          className="rounded-xl border border-slate-300 p-3"
        >
          <option value="">All Categories</option>

          {categories.map((cat) => (
            <option
              key={cat.id}
              value={cat.id}
            >
              {cat.name}
            </option>
          ))}
        </select>

        {/* Reporter */}

        <select
          value={reporter}
          onChange={(e) =>
            onReporterChange(e.target.value)
          }
          className="rounded-xl border border-slate-300 p-3"
        >
          <option value="">All Reporters</option>

          {reporters.map((rep) => (
            <option
              key={rep.id}
              value={rep.id}
            >
              {rep.firstName} {rep.lastName}
            </option>
          ))}
        </select>

        {/* Featured */}

        <select
          value={featured}
          onChange={(e) =>
            onFeaturedChange(e.target.value)
          }
          className="rounded-xl border border-slate-300 p-3"
        >
          <option value="">Featured</option>
          <option value="true">Featured</option>
          <option value="false">Not Featured</option>
        </select>

        {/* Breaking */}

        <select
          value={breaking}
          onChange={(e) =>
            onBreakingChange(e.target.value)
          }
          className="rounded-xl border border-slate-300 p-3"
        >
          <option value="">Breaking</option>
          <option value="true">Breaking</option>
          <option value="false">Normal</option>
        </select>

        {/* Trending */}

        <select
          value={trending}
          onChange={(e) =>
            onTrendingChange(e.target.value)
          }
          className="rounded-xl border border-slate-300 p-3"
        >
          <option value="">Trending</option>
          <option value="true">Trending</option>
          <option value="false">Normal</option>
        </select>

      </div>

    </div>
  );
}