"use client";

import Link from "next/link";
import {
  FilePlus2,
  Users,
  ClipboardCheck,
  FolderTree,
  Images,
  Settings,
} from "lucide-react";

const actions = [
  {
    title: "Create News",
    description: "Write and publish a new article",
    href: "/admin/posts/create",
    icon: FilePlus2,
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Manage Reporters",
    description: "View and manage reporters",
    href: "/admin/reporters",
    icon: Users,
    color: "from-violet-500 to-indigo-500",
  },
  {
    title: "Pending Review",
    description: "Approve or reject submissions",
    href: "/admin/posts?status=PENDING",
    icon: ClipboardCheck,
    color: "from-amber-500 to-orange-500",
  },
  {
    title: "Categories",
    description: "Manage news categories",
    href: "/admin/categories",
    icon: FolderTree,
    color: "from-emerald-500 to-green-500",
  },
  {
    title: "Gallery",
    description: "Manage media library",
    href: "/admin/gallery",
    icon: Images,
    color: "from-pink-500 to-rose-500",
  },
  {
    title: "Settings",
    description: "Website configuration",
    href: "/admin/settings",
    icon: Settings,
    color: "from-slate-600 to-slate-800",
  },
];

export default function QuickActions() {
  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-900">
          Quick Actions
        </h2>

        <p className="text-sm text-slate-500">
          Frequently used administration shortcuts
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
        {actions.map((action) => {
          const Icon = action.icon;

          return (
            <Link
              key={action.title}
              href={action.href}
              className="group overflow-hidden rounded-3xl border border-slate-200 bg-white transition-all duration-300 hover:-translate-y-1 hover:border-blue-300 hover:shadow-xl"
            >
              <div className="p-6">
                <div
                  className={`mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${action.color} shadow-lg transition-transform duration-300 group-hover:scale-110`}
                >
                  <Icon className="h-8 w-8 text-white" />
                </div>

                <h3 className="text-lg font-bold text-slate-900">
                  {action.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {action.description}
                </p>
              </div>

              <div className="border-t border-slate-100 bg-slate-50 px-6 py-4 text-sm font-semibold text-blue-600 transition group-hover:bg-blue-600 group-hover:text-white">
                Open →
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}