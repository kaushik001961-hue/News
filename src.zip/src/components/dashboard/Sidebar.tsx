"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { dashboardMenus, UserRole } from "./menu";

interface SidebarProps {
  role: UserRole;
}

export default function Sidebar({
  role,
}: SidebarProps) {
  const pathname = usePathname();

  const menus = dashboardMenus[role];

  const panelTitle =
    role === "ADMIN"
      ? "Admin Panel"
      : role === "EDITOR"
      ? "Editor Panel"
      : "Reporter Panel";

  return (
    <aside className="sticky top-0 flex h-screen w-72 flex-col bg-slate-900 text-white shadow-2xl">

      {/* Logo */}

      <div className="border-b border-slate-800 px-8 py-8">

        <h1 className="text-3xl font-black tracking-wide">
          AGS NEWS
        </h1>

        <p className="mt-2 text-sm text-slate-400">
          {panelTitle}
        </p>

      </div>

      {/* Navigation */}

      <nav className="flex-1 overflow-y-auto px-4 py-6 space-y-2">

        {menus.map((item) => {
          const Icon = item.icon;

          const active =
            pathname === item.href ||
            pathname.startsWith(item.href + "/");

          return (
            <Link
              key={item.title}
              href={item.href}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 transition-all duration-200 ${
                active
                  ? "bg-blue-600 text-white shadow-lg"
                  : "text-slate-300 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <Icon
                size={20}
                className={active ? "text-white" : "text-slate-400"}
              />

              <span className="font-medium">
                {item.title}
              </span>
            </Link>
          );
        })}

      </nav>

      {/* Footer */}

      <div className="border-t border-slate-800 p-5">

        <div className="rounded-xl bg-slate-800 p-4">

          <p className="text-sm font-semibold">
            AGS NEWS CMS
          </p>

          <p className="mt-1 text-xs text-slate-400">
            {panelTitle}
          </p>

        </div>

        <p className="mt-4 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} AGS NEWS
        </p>

      </div>

    </aside>
  );
}