"use client";

export default function DashboardSkeleton() {
  return (
    <div className="space-y-8 animate-pulse">

      {/* Header */}

      <div className="rounded-3xl border border-slate-200 bg-white p-8">

        <div className="h-10 w-80 rounded bg-slate-200" />

        <div className="mt-4 h-5 w-60 rounded bg-slate-100" />

        <div className="mt-8 flex gap-4">

          <div className="h-11 w-80 rounded-xl bg-slate-200" />

          <div className="h-11 w-11 rounded-xl bg-slate-200" />

          <div className="h-11 w-40 rounded-xl bg-slate-200" />

        </div>

      </div>

      {/* Stats */}

      <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">

        {Array.from({ length: 8 }).map((_, index) => (

          <div
            key={index}
            className="rounded-2xl border bg-white p-6"
          >

            <div className="flex justify-between">

              <div>

                <div className="h-4 w-24 rounded bg-slate-200" />

                <div className="mt-5 h-10 w-20 rounded bg-slate-300" />

              </div>

              <div className="h-16 w-16 rounded-2xl bg-slate-200" />

            </div>

          </div>

        ))}

      </div>

      {/* Charts */}

      <div className="grid gap-6 xl:grid-cols-3">

        <div className="xl:col-span-2 rounded-2xl border bg-white p-6">

          <div className="h-6 w-48 rounded bg-slate-200" />

          <div className="mt-8 h-[320px] rounded-xl bg-slate-100" />

        </div>

        <div className="rounded-2xl border bg-white p-6">

          <div className="h-6 w-36 rounded bg-slate-200" />

          <div className="mt-8 h-[320px] rounded-full bg-slate-100" />

        </div>

      </div>

      {/* Tables */}

      <div className="grid gap-6 xl:grid-cols-3">

        <div className="xl:col-span-2 rounded-2xl border bg-white p-6">

          <div className="h-6 w-48 rounded bg-slate-200" />

          <div className="mt-8 space-y-4">

            {Array.from({ length: 6 }).map((_, index) => (

              <div
                key={index}
                className="h-14 rounded bg-slate-100"
              />

            ))}

          </div>

        </div>

        <div className="rounded-2xl border bg-white p-6">

          <div className="h-6 w-40 rounded bg-slate-200" />

          <div className="mt-8 space-y-5">

            {Array.from({ length: 6 }).map((_, index) => (

              <div
                key={index}
                className="h-16 rounded bg-slate-100"
              />

            ))}

          </div>

        </div>

      </div>

      {/* Timeline */}

      <div className="rounded-2xl border bg-white p-6">

        <div className="h-6 w-52 rounded bg-slate-200" />

        <div className="mt-8 space-y-6">

          {Array.from({ length: 5 }).map((_, index) => (

            <div
              key={index}
              className="flex gap-4"
            >

              <div className="h-12 w-12 rounded-full bg-slate-200" />

              <div className="flex-1">

                <div className="h-4 w-56 rounded bg-slate-200" />

                <div className="mt-3 h-4 w-full rounded bg-slate-100" />

                <div className="mt-2 h-3 w-32 rounded bg-slate-100" />

              </div>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}