"use client";

import Link from "next/link";
import {
  CheckCircle2,
  Clock3,
  XCircle,
  Ban,
  User,
  Eye,
} from "lucide-react";

interface Reporter {
  id: string;
  reporterId?: string;

  firstName: string;
  lastName: string;

  email: string;

  district?: string;
  state?: string;

  status: string;

  active: boolean;

  createdAt: string;
}

interface Props {
  reporters: Reporter[];
}

function StatusBadge({
  status,
}: {
  status: string;
}) {
  switch (status) {
    case "APPROVED":
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
          <CheckCircle2 className="h-4 w-4" />
          Approved
        </span>
      );

    case "REJECTED":
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-700">
          <XCircle className="h-4 w-4" />
          Rejected
        </span>
      );

    case "BLOCKED":
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
          <Ban className="h-4 w-4" />
          Blocked
        </span>
      );

    default:
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
          <Clock3 className="h-4 w-4" />
          Pending
        </span>
      );
  }
}

export default function RecentReporters({
  reporters,
}: Props) {
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

      <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">

        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Recent Reporters
          </h2>

          <p className="text-sm text-slate-500">
            Latest registered reporters
          </p>
        </div>

        <Link
          href="/admin/reporters"
          className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-medium hover:bg-slate-100"
        >
          View All
        </Link>

      </div>

      <div className="divide-y divide-slate-100">

        {reporters.length === 0 ? (
          <div className="py-10 text-center text-slate-500">
            No reporters found.
          </div>
        ) : (
          reporters.slice(0, 6).map((reporter) => (
            <div
              key={reporter.id}
              className="flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition"
            >
              <div className="flex items-center gap-4">

                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-700 font-bold">
                  {reporter.firstName.charAt(0)}
                  {reporter.lastName.charAt(0)}
                </div>

                <div>

                  <h3 className="font-semibold text-slate-900">
                    {reporter.firstName} {reporter.lastName}
                  </h3>

                  <p className="text-sm text-slate-500">
                    {reporter.reporterId ?? "Not Assigned"}
                  </p>

                  <p className="text-xs text-slate-400">
                    {reporter.district ?? "-"}
                    {reporter.state
                      ? `, ${reporter.state}`
                      : ""}
                  </p>

                </div>

              </div>

              <div className="flex items-center gap-4">

                <StatusBadge
                  status={reporter.status}
                />

                <Link
                  href={`/admin/reporters/${reporter.id}`}
                  className="rounded-lg p-2 hover:bg-slate-100"
                >
                  <Eye className="h-5 w-5 text-slate-600" />
                </Link>

              </div>

            </div>
          ))
        )}

      </div>

    </div>
  );
}