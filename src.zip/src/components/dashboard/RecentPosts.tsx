"use client";

import Link from "next/link";
import {
  CheckCircle2,
  Clock3,
  Eye,
  FileText,
  MoreHorizontal,
  Pencil,
} from "lucide-react";

interface Post {
  id: string;
  title: string;
  status: string;
  createdAt: string;

  author?: {
    name: string;
  };

  category?: {
    name: string;
  } | null;
}

interface Props {
  posts: Post[];
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "PUBLISHED":
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
          <CheckCircle2 className="h-4 w-4" />
          Published
        </span>
      );

    case "DRAFT":
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
          <Pencil className="h-4 w-4" />
          Draft
        </span>
      );

    default:
      return (
        <span className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
          <Clock3 className="h-4 w-4" />
          Pending
        </span>
      );
  }
}

export default function RecentPosts({ posts }: Props) {
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">

      {/* Header */}

      <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">

        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Recent Articles
          </h2>

          <p className="text-sm text-slate-500">
            Latest news in the newsroom
          </p>
        </div>

        <Link
          href="/admin/posts"
          className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-medium transition hover:bg-slate-100"
        >
          View All
        </Link>

      </div>

      <div className="overflow-x-auto">

        <table className="w-full">

          <thead className="bg-slate-50 text-sm text-slate-500">

            <tr>
              <th className="px-6 py-4 text-left">Article</th>
              <th className="px-6 py-4 text-left">Category</th>
              <th className="px-6 py-4 text-left">Author</th>
              <th className="px-6 py-4 text-left">Status</th>
              <th className="px-6 py-4 text-left">Created</th>
              <th className="px-6 py-4 text-center">Action</th>
            </tr>

          </thead>

          <tbody>

            {posts.length === 0 ? (

              <tr>

                <td
                  colSpan={6}
                  className="py-12 text-center text-slate-500"
                >
                  <FileText className="mx-auto mb-3 h-10 w-10 text-slate-300" />

                  No articles found.

                </td>

              </tr>

            ) : (

              posts.slice(0, 6).map((post) => (

                <tr
                  key={post.id}
                  className="border-t border-slate-100 hover:bg-slate-50"
                >

                  <td className="px-6 py-5">

                    <div className="font-semibold text-slate-900">
                      {post.title}
                    </div>

                  </td>

                  <td className="px-6 py-5">

                    <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                      {post.category?.name ?? "Uncategorized"}
                    </span>

                  </td>

                  <td className="px-6 py-5">
                    {post.author?.name ?? "-"}
                  </td>

                  <td className="px-6 py-5">
                    <StatusBadge status={post.status} />
                  </td>

                  <td className="px-6 py-5 text-slate-500">
                    {new Date(post.createdAt).toLocaleDateString()}
                  </td>

                  <td className="px-6 py-5 text-center">

                    <Link
                      href={`/admin/posts/${post.id}`}
                      className="inline-flex rounded-lg p-2 transition hover:bg-slate-100"
                    >
                      <Eye className="h-5 w-5 text-slate-600" />
                    </Link>

                    <button className="rounded-lg p-2 transition hover:bg-slate-100">
                      <MoreHorizontal className="h-5 w-5 text-slate-500" />
                    </button>

                  </td>

                </tr>

              ))

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}