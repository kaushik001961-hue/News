export default function AdminDashboard() {
  return (
    <div className="bg-red-500 p-10 text-white">
      <h1 className="text-5xl font-bold">Admin Dashboard</h1>
    </div>
  );
}