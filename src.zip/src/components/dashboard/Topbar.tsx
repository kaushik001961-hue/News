"use client";

import Link from "next/link";

import {
  Search,
  Bell,
  Settings,
  UserCircle,
  Menu,
  Home,
} from "lucide-react";

import LogoutButton from "@/components/auth/LogoutButton";
import { UserRole } from "./menu";

interface TopbarProps {
  role: UserRole;

  user: {
    id: string;
    name?: string | null;
    email?: string | null;
    role: UserRole;
    reporterId?: string;
  };
}

export default function Topbar({
  role,
  user,
}: TopbarProps) {
  const title =
    role === "ADMIN"
      ? "AGS NEWS"
      : role === "EDITOR"
      ? "Welcome "
      : "Reporter Dashboard";

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white">
      <div className="flex h-16 items-center justify-between px-6">

        {/* Left */}

        <div className="flex items-center gap-4">

          <button className="rounded-lg p-2 hover:bg-slate-100 lg:hidden">
            <Menu size={22} />
          </button>

          <div>
            <h2 className="text-xl font-bold text-slate-800">
              {title}
            </h2>

            <p className="text-sm text-slate-500">
             
            </p>
          </div>

        </div>

        {/* Center */}

        <div className="hidden w-full max-w-md lg:block">

          <div className="relative">

            <Search
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />

            <input
              type="text"
              placeholder="Search..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-10 pr-4 outline-none transition focus:border-blue-500 focus:bg-white"
            />

          </div>

        </div>

        {/* Right */}

        <div className="flex items-center gap-3">

          {/* Website */}

          <Link
            href="/"
            className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
          >
            <Home size={18} />
            Website
          </Link>

          {/* Notifications */}

          <button className="relative rounded-xl p-2 hover:bg-slate-100">

            <Bell size={20} />

            <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-500"></span>

          </button>

          {/* Settings */}

          <button className="rounded-xl p-2 hover:bg-slate-100">

            <Settings size={20} />

          </button>

          {/* User */}

          <button className="flex items-center gap-3 rounded-xl border border-slate-200 px-3 py-2 hover:bg-slate-50">

            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white">

              <UserCircle size={22} />

            </div>

            <div className="hidden text-left md:block">

              <p className="font-semibold text-slate-800">
                {user.name ?? "AGS User"}
              </p>

              <p className="text-xs text-slate-500">
                {user.role}
              </p>

            </div>

          </button>

          {/* Logout */}

          <LogoutButton />

        </div>

      </div>
    </header>
  );
}