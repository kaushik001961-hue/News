"use client";

import {
  Newspaper,
  UserPlus,
  CheckCircle2,
  FileEdit,
  ImagePlus,
  Clock3,
} from "lucide-react";

const activities = [
  {
    id: 1,
    title: "New article published",
    description: "Government announces new education policy",
    time: "5 minutes ago",
    icon: Newspaper,
    color: "bg-blue-500",
  },
  {
    id: 2,
    title: "Reporter registered",
    description: "Rahul Patel joined AGS News",
    time: "18 minutes ago",
    icon: UserPlus,
    color: "bg-violet-500",
  },
  {
    id: 3,
    title: "Article approved",
    description: "Heavy Rainfall Alert approved by Editor",
    time: "42 minutes ago",
    icon: CheckCircle2,
    color: "bg-emerald-500",
  },
  {
    id: 4,
    title: "News updated",
    description: "Technology section article edited",
    time: "1 hour ago",
    icon: FileEdit,
    color: "bg-amber-500",
  },
  {
    id: 5,
    title: "Gallery updated",
    description: "12 new images uploaded",
    time: "2 hours ago",
    icon: ImagePlus,
    color: "bg-pink-500",
  },
];

export default function ActivityTimeline() {
  return (
    <div className="rounded-3xl bg-white shadow-sm">

      <div className="border-b border-slate-100 px-6 py-5">
        <h2 className="text-xl font-bold text-slate-900">
          Activity Timeline
        </h2>

        <p className="text-sm text-slate-500">
          Latest newsroom activity
        </p>
      </div>

      <div className="p-6">

        <div className="relative">

          {/* Vertical Line */}

          <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-slate-200" />

          <div className="space-y-8">

            {activities.map((activity) => {
              const Icon = activity.icon;

              return (
                <div
                  key={activity.id}
                  className="relative flex items-start gap-5"
                >
                  {/* Icon */}

                  <div
                    className={`relative z-10 flex h-14 w-14 items-center justify-center rounded-full ${activity.color} shadow-lg`}
                  >
                    <Icon className="h-6 w-6 text-white" />
                  </div>

                  {/* Content */}

                  <div className="flex-1 rounded-2xl border border-slate-100 bg-slate-50 p-5 transition hover:border-blue-200 hover:bg-white">

                    <div className="flex items-center justify-between">

                      <h3 className="font-semibold text-slate-900">
                        {activity.title}
                      </h3>

                      <div className="flex items-center gap-2 text-sm text-slate-500">
                        <Clock3 className="h-4 w-4" />
                        {activity.time}
                      </div>

                    </div>

                    <p className="mt-2 text-sm leading-6 text-slate-600">
                      {activity.description}
                    </p>

                  </div>

                </div>
              );
            })}

          </div>

        </div>

      </div>

    </div>
  );
}