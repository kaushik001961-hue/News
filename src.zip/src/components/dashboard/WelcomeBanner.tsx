"use client";

import { CalendarDays, Sparkles } from "lucide-react";

interface WelcomeBannerProps {
  title: string;
  subtitle: string;
  name: string;
  email: string;
}

export default function WelcomeBanner({
  title,
  subtitle,
  name,
  email,
}: WelcomeBannerProps) {
  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-500 p-8 text-white shadow-xl">

      {/* Background Decoration */}
      <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
      <div className="absolute -bottom-24 left-10 h-52 w-52 rounded-full bg-white/10 blur-3xl" />

      <div className="relative z-10 flex flex-col justify-between gap-8 lg:flex-row lg:items-center">

        {/* Left */}

        <div className="max-w-2xl">

          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-sm backdrop-blur-md">
            <Sparkles className="h-4 w-4" />
            News Management System
          </div>

          <h2 className="text-4xl font-bold">
            {title}
          </h2>

          <p className="mt-4 max-w-2xl text-blue-100 text-lg leading-8">
            {subtitle}
          </p>

          <div className="mt-6 flex items-center gap-2 text-sm text-blue-100">
            <CalendarDays className="h-4 w-4" />
            {today}
          </div>

        </div>

        {/* Right */}

        <div className="flex items-center gap-5 rounded-2xl border border-white/20 bg-white/10 px-6 py-5 backdrop-blur-xl">

          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white text-3xl font-bold text-blue-600 shadow-lg">
            {name.charAt(0)}
          </div>

          <div>

            <p className="text-sm uppercase tracking-widest text-blue-100">
              Logged in as
            </p>

            <h3 className="text-2xl font-bold">
              {name}
            </h3>

            <p className="text-blue-100">
              {email}
            </p>

            <div className="mt-3 inline-flex rounded-full bg-emerald-500 px-3 py-1 text-xs font-semibold text-white">
              ● Online
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}