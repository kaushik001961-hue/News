import {
  LayoutDashboard,
  Newspaper,
  FolderTree,
  Users,
  Tv,
  ImageIcon,
  BarChart3,
  Settings,
  ClipboardCheck,
  FileText,
  UserCircle,
  BadgeCheck,
  BellRing,
  LucideIcon,
} from "lucide-react";

export type UserRole = "ADMIN" | "EDITOR" | "REPORTER";

export interface MenuItem {
  title: string;
  href: string;
  icon: LucideIcon;
}

export const dashboardMenus: Record<UserRole, MenuItem[]> = {
  ADMIN: [
    {
      title: "Dashboard",
      href: "/admin",
      icon: LayoutDashboard,
    },
    {
      title: "Posts",
      href: "/admin/posts",
      icon: Newspaper,
    },
    {
      title: "Categories",
      href: "/admin/categories",
      icon: FolderTree,
    },
    {
      title: "Reporters",
      href: "/admin/reporters",
      icon: Users,
    },
    {
      title: "Live TV",
      href: "/admin/live-tv",
      icon: Tv,
    },
    {
      title: "Media Library",
      href: "/admin/media",
      icon: ImageIcon,
    },
    {
      title: "Users",
      href: "/admin/users",
      icon: Users,
    },
    {
      title: "Analytics",
      href: "/admin/analytics",
      icon: BarChart3,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
  ],

  EDITOR: [
    {
      title: "Dashboard",
      href: "/editor",
      icon: LayoutDashboard,
    },
    {
      title: "Posts",
      href: "/editor/posts",
      icon: Newspaper,
    },
    {
      title: "Categories",
      href: "/editor/categories",
      icon: FolderTree,
    },
    {
      title: "Review Queue",
      href: "/editor/review",
      icon: ClipboardCheck,
    },
    {
      title: "Media Library",
      href: "/editor/media",
      icon: ImageIcon,
    },
    {
      title: "Notifications",
      href: "/editor/notifications",
      icon: BellRing,
    },
    {
      title: "Profile",
      href: "/editor/profile",
      icon: UserCircle,
    },
  ],

  REPORTER: [
    {
      title: "Dashboard",
      href: "/reporter",
      icon: LayoutDashboard,
    },
    {
      title: "My Stories",
      href: "/reporter/posts",
      icon: FileText,
    },
    {
      title: "Press Card",
      href: "/reporter/press-card",
      icon: BadgeCheck,
    },
    {
      title: "Notifications",
      href: "/reporter/notifications",
      icon: BellRing,
    },
    {
      title: "Profile",
      href: "/reporter/profile",
      icon: UserCircle,
    },
  ],
};