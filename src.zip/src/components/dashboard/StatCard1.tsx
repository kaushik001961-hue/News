"use client";

import {
  Newspaper,
  FileClock,
  CheckCircle2,
  Users,
  UserCheck,
  FolderKanban,
  Eye,
  TrendingUp,
} from "lucide-react";

const stats = [
  {
    title: "Total News",
    value: "2,845",
    change: "+12%",
    icon: Newspaper,
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Published",
    value: "2,120",
    change: "+8%",
    icon: CheckCircle2,
    color: "from-emerald-500 to-green-500",
  },
  {
    title: "Pending Review",
    value: "86",
    change: "-4%",
    icon: FileClock,
    color: "from-amber-500 to-orange-500",
  },
  {
    title: "Reporters",
    value: "148",
    change: "+15%",
    icon: Users,
    color: "from-violet-500 to-indigo-500",
  },
  {
    title: "Editors",
    value: "12",
    change: "+2%",
    icon: UserCheck,
    color: "from-pink-500 to-rose-500",
  },
  {
    title: "Categories",
    value: "24",
    change: "+1",
    icon: FolderKanban,
    color: "from-sky-500 to-blue-500",
  },
  {
    title: "Visitors Today",
    value: "18,920",
    change: "+22%",
    icon: Eye,
    color: "from-purple-500 to-fuchsia-500",
  },
  {
    title: "Monthly Growth",
    value: "18.4%",
    change: "+3%",
    icon: TrendingUp,
    color: "from-teal-500 to-emerald-500",
  },
];

export default function StatsGrid() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map((item) => {
        const Icon = item.icon;

        return (
          <div
            key={item.title}
            className="group rounded-3xl bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">
                  {item.title}
                </p>

                <h2 className="mt-3 text-4xl font-bold text-slate-900">
                  {item.value}
                </h2>

                <div className="mt-4 inline-flex rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold text-emerald-600">
                  {item.change}
                </div>
              </div>

              <div
                className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${item.color} shadow-lg transition-transform duration-300 group-hover:scale-110`}
              >
                <Icon className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}