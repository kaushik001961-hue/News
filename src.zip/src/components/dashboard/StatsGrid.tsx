"use client";

import {
  Newspaper,
  FileCheck2,
  FileText,
  Clock3,
  Users,
  UserCheck,
  FolderKanban,
  Activity,
  TrendingUp,
} from "lucide-react";

interface Props {
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  pendingPosts: number;
  totalReporters: number;
  approvedReporters: number;
  activeReporters: number;
  totalCategories: number;
}

interface CardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  color: string;
  bg: string;
}

function StatCard({
  title,
  value,
  icon,
  color,
  bg,
}: CardProps) {
  return (
    <div
      className={`group relative overflow-hidden rounded-3xl border border-white/40 ${bg}
      p-6 shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl`}
    >
      <div className="absolute right-0 top-0 h-28 w-28 rounded-full bg-white/10 blur-2xl" />

      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-sm font-semibold text-slate-600">
            {title}
          </p>

          <h2 className="mt-3 text-4xl font-bold text-slate-900">
            {value.toLocaleString()}
          </h2>

          <div className="mt-4 inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-medium text-emerald-700">
            <TrendingUp className="h-3.5 w-3.5" />
            Live
          </div>
        </div>

        <div
          className={`flex h-16 w-16 items-center justify-center rounded-2xl text-white shadow-lg ${color}
          transition-transform duration-300 group-hover:scale-110`}
        >
          {icon}
        </div>
      </div>
    </div>
  );
}

export default function StatsGrid({
  totalPosts,
  publishedPosts,
  draftPosts,
  pendingPosts,
  totalReporters,
  approvedReporters,
  activeReporters,
  totalCategories,
}: Props) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">

      <StatCard
        title="Total Articles"
        value={totalPosts}
        icon={<Newspaper size={28} />}
        color="bg-blue-600"
        bg="bg-gradient-to-br from-white to-blue-50"
      />

      <StatCard
        title="Published"
        value={publishedPosts}
        icon={<FileCheck2 size={28} />}
        color="bg-green-600"
        bg="bg-gradient-to-br from-white to-green-50"
      />

      <StatCard
        title="Drafts"
        value={draftPosts}
        icon={<FileText size={28} />}
        color="bg-slate-600"
        bg="bg-gradient-to-br from-white to-slate-100"
      />

      <StatCard
        title="Pending Review"
        value={pendingPosts}
        icon={<Clock3 size={28} />}
        color="bg-orange-500"
        bg="bg-gradient-to-br from-white to-orange-50"
      />

      <StatCard
        title="Reporters"
        value={totalReporters}
        icon={<Users size={28} />}
        color="bg-purple-600"
        bg="bg-gradient-to-br from-white to-purple-50"
      />

      <StatCard
        title="Approved"
        value={approvedReporters}
        icon={<UserCheck size={28} />}
        color="bg-emerald-600"
        bg="bg-gradient-to-br from-white to-emerald-50"
      />

      <StatCard
        title="Active"
        value={activeReporters}
        icon={<Activity size={28} />}
        color="bg-cyan-600"
        bg="bg-gradient-to-br from-white to-cyan-50"
      />

      <StatCard
        title="Categories"
        value={totalCategories}
        icon={<FolderKanban size={28} />}
        color="bg-pink-600"
        bg="bg-gradient-to-br from-white to-pink-50"
      />

    </div>
  );
}