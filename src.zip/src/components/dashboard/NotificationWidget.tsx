"use client";

import {
  Bell,
  AlertTriangle,
  CheckCircle2,
  MessageSquare,
  UserPlus,
} from "lucide-react";

const notifications = [
  {
    id: 1,
    title: "5 articles waiting for approval",
    time: "10 min ago",
    icon: AlertTriangle,
    color: "bg-amber-100 text-amber-600",
  },
  {
    id: 2,
    title: "New reporter registration received",
    time: "35 min ago",
    icon: UserPlus,
    color: "bg-blue-100 text-blue-600",
  },
  {
    id: 3,
    title: "Article published successfully",
    time: "1 hour ago",
    icon: CheckCircle2,
    color: "bg-emerald-100 text-emerald-600",
  },
  {
    id: 4,
    title: "3 new comments received",
    time: "2 hours ago",
    icon: MessageSquare,
    color: "bg-purple-100 text-purple-600",
  },
];

export default function NotificationWidget() {
  return (
    <div className="rounded-3xl bg-white shadow-sm">

      <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">

        <div className="flex items-center gap-3">
          <Bell className="h-6 w-6 text-blue-600" />

          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Notifications
            </h2>

            <p className="text-sm text-slate-500">
              Latest system updates
            </p>
          </div>
        </div>

        <span className="rounded-full bg-red-500 px-3 py-1 text-xs font-semibold text-white">
          {notifications.length}
        </span>

      </div>

      <div className="divide-y divide-slate-100">

        {notifications.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.id}
              className="flex items-start gap-4 p-5 transition hover:bg-slate-50"
            >
              <div
                className={`flex h-12 w-12 items-center justify-center rounded-xl ${item.color}`}
              >
                <Icon className="h-5 w-5" />
              </div>

              <div className="flex-1">
                <p className="font-medium text-slate-900">
                  {item.title}
                </p>

                <p className="mt-1 text-sm text-slate-500">
                  {item.time}
                </p>
              </div>
            </div>
          );
        })}

      </div>

      <div className="border-t border-slate-100 p-5">
        <button className="w-full rounded-xl bg-blue-600 py-3 font-semibold text-white transition hover:bg-blue-700">
          View All Notifications
        </button>
      </div>

    </div>
  );
}
