"use client";

import {
  Target,
  TrendingUp,
  Newspaper,
  Users,
} from "lucide-react";

const performance = [
  {
    title: "Publishing Target",
    value: "84%",
    progress: 84,
    icon: Target,
    color: "bg-blue-500",
  },
  {
    title: "Reporter Productivity",
    value: "91%",
    progress: 91,
    icon: Users,
    color: "bg-emerald-500",
  },
  {
    title: "Article Approval",
    value: "76%",
    progress: 76,
    icon: Newspaper,
    color: "bg-amber-500",
  },
  {
    title: "Monthly Growth",
    value: "+18%",
    progress: 18,
    icon: TrendingUp,
    color: "bg-violet-500",
  },
];

export default function MonthlyPerformance() {
  return (
    <div className="rounded-3xl bg-white shadow-sm">
      <div className="border-b border-slate-100 px-6 py-5">
        <h2 className="text-xl font-bold text-slate-900">
          Monthly Performance
        </h2>

        <p className="text-sm text-slate-500">
          Overall newsroom performance this month
        </p>
      </div>

      <div className="space-y-6 p-6">
        {performance.map((item) => {
          const Icon = item.icon;

          return (
            <div key={item.title}>
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-xl ${item.color}`}
                  >
                    <Icon className="h-5 w-5 text-white" />
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-900">
                      {item.title}
                    </h4>

                    <p className="text-sm text-slate-500">
                      {item.value}
                    </p>
                  </div>
                </div>

                <span className="font-bold text-slate-900">
                  {item.progress}%
                </span>
              </div>

              <div className="h-3 overflow-hidden rounded-full bg-slate-200">
                <div
                  className={`${item.color} h-full rounded-full transition-all duration-700`}
                  style={{ width: `${item.progress}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}