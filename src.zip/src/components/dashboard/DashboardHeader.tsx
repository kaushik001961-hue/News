"use client";

import { Search, Bell, CalendarDays } from "lucide-react";
import { useSession } from "next-auth/react";

export default function DashboardHeader() {
  const { data: session } = useSession();

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-col gap-6 p-6 lg:flex-row lg:items-center lg:justify-between">

        {/* Left */}
        <div>
          <h1 className="text-3xl font-bold text-slate-900">
            Admin Dashboard
          </h1>

          <div className="mt-2 flex items-center gap-2 text-sm text-slate-500">
            <CalendarDays className="h-4 w-4" />
            <span>{today}</span>
          </div>
        </div>

        {/* Search */}
        <div className="flex-1 lg:max-w-xl">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />

            <input
              type="text"
              placeholder="Search news, reporters, users..."
              className="h-14 w-full rounded-full border border-slate-200 bg-slate-50 pl-12 pr-4 text-sm outline-none transition-all focus:border-blue-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Right */}
        <div className="flex items-center gap-5">

          <button className="relative rounded-full bg-slate-100 p-3 transition hover:bg-slate-200">
            <Bell className="h-5 w-5 text-slate-700" />

            <span className="absolute right-2 top-2 h-2.5 w-2.5 rounded-full bg-red-500" />
          </button>

          <div className="flex items-center gap-3">

            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 text-lg font-bold text-white">
              {session?.user?.name?.charAt(0).toUpperCase() ?? "A"}
            </div>

            <div>
              <p className="font-semibold text-slate-900">
                {session?.user?.name ?? "Administrator"}
              </p>

              <p className="text-sm text-slate-500">
                {session?.user?.email}
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}