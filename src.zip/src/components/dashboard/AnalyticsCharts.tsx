"use client";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

interface PublishingItem {
  month: string;
  published: number;
  drafts?: number;
}

interface CategoryItem {
  name: string;
  value: number;
}

interface Props {
  publishingData: PublishingItem[];
  categoryData: CategoryItem[];
}

const COLORS = [
  "#2563eb",
  "#22c55e",
  "#f59e0b",
  "#8b5cf6",
  "#ef4444",
  "#06b6d4",
];

export default function AnalyticsCharts({
  publishingData,
  categoryData,
}: Props) {
  return (
    <div className="grid gap-6 xl:grid-cols-3">

      {/* Publishing */}

      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm xl:col-span-2">

        <div className="mb-6 flex items-center justify-between">

          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Publishing Trend
            </h2>

            <p className="text-sm text-slate-500">
              Monthly published articles
            </p>
          </div>

          <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-600">
            Last 6 Months
          </span>

        </div>

        <div className="h-80">

          <ResponsiveContainer width="100%" height="100%">

            <AreaChart data={publishingData}>

              <defs>

                <linearGradient
                  id="publishedGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop
                    offset="5%"
                    stopColor="#2563eb"
                    stopOpacity={0.8}
                  />
                  <stop
                    offset="95%"
                    stopColor="#2563eb"
                    stopOpacity={0}
                  />
                </linearGradient>

              </defs>

              <CartesianGrid strokeDasharray="3 3" />

              <XAxis dataKey="month" />

              <YAxis />

              <Tooltip />

              <Area
                type="monotone"
                dataKey="published"
                stroke="#2563eb"
                strokeWidth={3}
                fill="url(#publishedGradient)"
              />

            </AreaChart>

          </ResponsiveContainer>

        </div>

      </div>

      {/* Categories */}

      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">

        <h2 className="text-xl font-bold text-slate-900">
          Categories
        </h2>

        <p className="mb-6 text-sm text-slate-500">
          News distribution
        </p>

        <div className="h-72">

          <ResponsiveContainer width="100%" height="100%">

            <PieChart>

              <Pie
                data={categoryData}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={95}
              >
                {categoryData.map((item, index) => (
                  <Cell
                    key={item.name}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>

              <Tooltip />

            </PieChart>

          </ResponsiveContainer>

        </div>

        <div className="mt-4 space-y-3">

          {categoryData.map((item, index) => (
            <div
              key={item.name}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">

                <span
                  className="h-3 w-3 rounded-full"
                  style={{
                    backgroundColor:
                      COLORS[index % COLORS.length],
                  }}
                />

                <span className="text-sm font-medium text-slate-700">
                  {item.name}
                </span>

              </div>

              <span className="text-sm font-semibold">
                {item.value}%
              </span>

            </div>
          ))}

        </div>

      </div>

    </div>
  );
}