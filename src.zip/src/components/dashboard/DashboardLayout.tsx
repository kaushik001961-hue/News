"use client";

import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import { UserRole } from "./menu";

interface DashboardLayoutProps {
  children: ReactNode;
  role: UserRole;
  user: {
    id: string;
    name?: string | null;
    email?: string | null;
    role: UserRole;
    reporterId?: string;
  };
}

export default function DashboardLayout({
  children,
  role,
  user,
}: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen bg-slate-100">
      <Sidebar role={role} />

      <div className="flex flex-1 flex-col overflow-hidden">
        <Topbar role={role} user={user} />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="mx-auto max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}