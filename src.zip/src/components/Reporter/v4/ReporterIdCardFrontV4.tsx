"use client";

import Image from "next/image";
import { BadgeCheck, Mail, Phone, MapPin } from "lucide-react";

import { CardSideProps } from "./types";

import CardContainer from "./components/CardContainer";
import Background from "./components/Background";
import GoldBorder from "./components/GoldBorder";
import Watermark from "./components/Watermark";
import PrintSafeArea from "./components/PrintSafeArea";

import ReporterPhoto from "./components/ReporterPhoto";
import ReporterQRCode from "./components/QRCode";
import ReporterBarcode from "./components/Barcode";

export default function ReporterIdCardFrontV4({
  reporter,
}: CardSideProps) {
  return (
    <CardContainer>
      <Background />

      <Watermark />

      <GoldBorder />

      {/* Security Hologram */}

      <div
        className="
          absolute
          top-3
          right-3
          h-10
          w-10
          rounded-full
          border
          border-white/70
          bg-gradient-to-br
          from-cyan-300/30
          via-violet-300/20
          to-yellow-300/30
          backdrop-blur-md
        "
      >
        <div className="absolute inset-1 rounded-full border border-white/50" />
      </div>

      <PrintSafeArea>
        <div className="flex h-full flex-col">

          {/* Header */}

          <div className="text-center">

            <Image
              src="/images/ags-news-logo.png"
              alt="AGS NEWS"
              width={42}
              height={42}
              className="mx-auto"
            />

            <h1 className="mt-1 text-lg font-black tracking-widest text-red-800">
              AGS NEWS
            </h1>

            <p className="text-[9px] uppercase tracking-[3px] text-gray-600">
              PRESS IDENTITY CARD
            </p>

            <div className="mx-auto mt-2 h-[2px] w-40 bg-gradient-to-r from-yellow-500 via-yellow-200 to-yellow-500" />

          </div>

          {/* Reporter Photo */}

          <div className="mt-3 flex justify-center">

            <ReporterPhoto
              photo={reporter.photo}
              name={`${reporter.firstName} ${reporter.lastName}`}
            />

          </div>

          {/* Reporter Name */}

          <div className="mt-3 text-center">

            <h2 className="text-[12px] font-black uppercase tracking-wide text-gray-900">
              {reporter.firstName}{" "}
              {reporter.middleName}{" "}
              {reporter.lastName}
            </h2>

            <div className="mt-2 inline-flex items-center gap-2 rounded-full bg-red-700 px-4 py-1 text-[8px] font-bold uppercase text-white">

              <BadgeCheck size={12} />

              {reporter.designation || "Reporter"}

            </div>

          </div>
                    {/* Information */}

          <div className="mt-3 rounded-xl border border-gray-200 bg-white/95 p-3 shadow-sm">

            <div className="space-y-2">

              <div className="flex items-center gap-2">

                <span className="w-20 text-[7px] font-bold uppercase text-gray-500">
                  Reporter ID
                </span>

                <span className="text-[8px] font-bold text-red-700">
                  {reporter.reporterId}
                </span>

              </div>

              <div className="flex items-center gap-2">

                <Phone
                  size={11}
                  className="text-red-700"
                />

                <span className="truncate text-[8px] font-medium">
                  {reporter.phone}
                </span>

              </div>

              <div className="flex items-center gap-2">

                <Mail
                  size={11}
                  className="text-red-700"
                />

                <span className="truncate text-[8px] font-medium">
                  {reporter.email}
                </span>

              </div>

              <div className="flex items-center gap-2">

                <MapPin
                  size={11}
                  className="text-red-700"
                />

                <span className="truncate text-[8px] font-medium">
                  {reporter.district}, {reporter.state}
                </span>

              </div>

            </div>

          </div>

          {/* Barcode & QR */}

          <div className="mt-3 flex items-end justify-between">

            <div className="flex-1">

              <ReporterBarcode
                value={
                  reporter.barcode ??
                  reporter.reporterId
                }
              />

            </div>

            <div className="ml-3">

              <ReporterQRCode
                value={
                  reporter.qrCode ??
                  `https://agsnews.in/verify/${reporter.reporterId}`
                }
              />

            </div>

          </div>

          {/* Verification Badge */}

          <div className="mt-3 flex items-center justify-center gap-2 rounded-full bg-green-100 py-1">

            <BadgeCheck
              size={14}
              className="text-green-700"
            />

            <span className="text-[8px] font-bold uppercase tracking-wide text-green-700">
              Verified Reporter
            </span>

          </div>
                    {/* Footer */}

          <div className="mt-auto">

            <div className="flex items-center justify-between border-t border-gray-300 pt-2">

              <div>

                <p className="text-[6px] font-semibold uppercase text-gray-500">
                  Valid Till
                </p>

                <p className="text-[8px] font-bold text-red-700">
                  {reporter.expiryDate || "--"}
                </p>

              </div>

              <div className="text-right">

                <p className="text-[6px] font-semibold uppercase text-gray-500">
                  Card No.
                </p>

                <p className="text-[8px] font-bold text-gray-800">
                  {reporter.reporterId}
                </p>

              </div>

            </div>

            {/* Security Strip */}

            <div className="mt-2 rounded bg-gradient-to-r from-red-900 via-red-700 to-red-900 py-1">

              <p className="text-center text-[5px] font-bold uppercase tracking-[2px] text-white">

                AGS NEWS • OFFICIAL PRESS • VERIFIED REPORTER • AGS NEWS

              </p>

            </div>

          </div>

        </div>

      </PrintSafeArea>

    </CardContainer>
  );
}