"use client";

import { ReactNode } from "react";

interface PrintLayoutV5Props {
  front: ReactNode;
  back: ReactNode;
}

export default function PrintLayoutV5({
  front,
  back,
}: PrintLayoutV5Props) {
  return (
    <>
      {/* Screen Preview */}
      <div className="mx-auto flex flex-wrap justify-center gap-8 print:hidden">
        {front}
        {back}
      </div>

      {/* Print Layout */}
      <div className="hidden print:block">
        <div className="mx-auto flex flex-col items-center gap-6 pt-8">
          {/* Front */}
          <div className="relative">
            {front}

            {/* Cut Marks */}
            <div className="absolute -left-2 top-1/2 h-4 w-px -translate-y-1/2 bg-black" />
            <div className="absolute -right-2 top-1/2 h-4 w-px -translate-y-1/2 bg-black" />
            <div className="absolute left-1/2 -top-2 h-px w-4 -translate-x-1/2 bg-black" />
            <div className="absolute left-1/2 -bottom-2 h-px w-4 -translate-x-1/2 bg-black" />
          </div>

          {/* Back */}
          <div className="relative">
            {back}

            {/* Cut Marks */}
            <div className="absolute -left-2 top-1/2 h-4 w-px -translate-y-1/2 bg-black" />
            <div className="absolute -right-2 top-1/2 h-4 w-px -translate-y-1/2 bg-black" />
            <div className="absolute left-1/2 -top-2 h-px w-4 -translate-x-1/2 bg-black" />
            <div className="absolute left-1/2 -bottom-2 h-px w-4 -translate-x-1/2 bg-black" />
          </div>
        </div>
      </div>
    </>
  );
}