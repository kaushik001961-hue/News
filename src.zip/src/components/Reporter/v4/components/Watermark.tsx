"use client";

import Image from "next/image";

export default function Watermark() {
  return (
    <>
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        <Image
          src="/images/ags-news-logo.png"
          alt=""
          width={170}
          height={170}
          className="rotate-[-25deg] opacity-[0.05]"
        />
      </div>

      <div className="absolute bottom-[4mm] left-0 right-0">
        <p className="text-center text-[4px] font-bold uppercase tracking-[3px] text-red-300">
          AGS NEWS • OFFICIAL PRESS • AGS NEWS • OFFICIAL PRESS • AGS NEWS
        </p>
      </div>
    </>
  );
}