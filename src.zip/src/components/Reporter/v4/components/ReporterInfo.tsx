"use client";

import { ReporterCardData } from "../types";

interface Props {
  reporter: ReporterCardData;
}

export default function ReporterInfo({
  reporter,
}: Props) {
  const fullName = [
    reporter.firstName,
    reporter.middleName,
    reporter.lastName,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className="flex flex-col justify-center space-y-1">
      <h2 className="text-[15px] font-extrabold uppercase leading-tight text-gray-900">
        {fullName}
      </h2>

      <div className="inline-flex w-fit rounded bg-red-700 px-2 py-0.5 text-[7px] font-bold uppercase tracking-wide text-white">
        {reporter.designation}
      </div>

      <div className="space-y-0.5 pt-1 text-[8px] text-gray-700">
        <p>
          <span className="font-semibold">Reporter ID:</span>{" "}
          {reporter.reporterId}
        </p>

        <p>
          <span className="font-semibold">Phone:</span>{" "}
          {reporter.phone}
        </p>

        <p className="truncate">
          <span className="font-semibold">Email:</span>{" "}
          {reporter.email}
        </p>

        <p>
          <span className="font-semibold">District:</span>{" "}
          {reporter.district}
        </p>
      </div>
    </div>
  );
}