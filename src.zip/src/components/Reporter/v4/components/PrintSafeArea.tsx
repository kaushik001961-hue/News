"use client";

import { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export default function PrintSafeArea({
  children,
}: Props) {
  return (
    <div className="absolute inset-[2.5mm]">
      {children}
    </div>
  );
}