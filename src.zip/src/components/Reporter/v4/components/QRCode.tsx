"use client";

import QRCode from "react-qr-code";

interface Props {
  value: string;
}

export default function ReporterQRCode({ value }: Props) {
  return (
    <div className="rounded-lg bg-white p-1 shadow-sm">
      <QRCode
        value={value}
        size={60}
        bgColor="#ffffff"
        fgColor="#000000"
        level="M"
      />
    </div>
  );
}