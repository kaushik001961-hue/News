"use client";

import {
  CalendarDays,
  Droplets,
  GraduationCap,
  Briefcase,
  MapPinned,
  Newspaper,
} from "lucide-react";

import { ReporterCardData } from "../types";

interface Props {
  reporter: ReporterCardData;
}

function Item({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value?: string | number | null;
}) {
  return (
    <div className="flex items-start gap-2 rounded-lg bg-white p-2 shadow-sm">
      <div className="mt-0.5 text-red-700">{icon}</div>

      <div className="min-w-0">
        <p className="text-[6px] uppercase tracking-wide text-gray-500">
          {label}
        </p>

        <p className="truncate text-[7px] font-semibold text-gray-800">
          {value || "-"}
        </p>
      </div>
    </div>
  );
}

export default function ReporterDetails({
  reporter,
}: Props) {
  return (
    <div className="grid grid-cols-2 gap-2">
      <Item
        icon={<Droplets size={12} />}
        label="Blood"
        value={reporter.bloodGroup}
      />

      <Item
        icon={<CalendarDays size={12} />}
        label="DOB"
        value={reporter.dob}
      />

      <Item
        icon={<MapPinned size={12} />}
        label="State"
        value={reporter.state}
      />

      <Item
        icon={<MapPinned size={12} />}
        label="District"
        value={reporter.district}
      />

      <Item
        icon={<Newspaper size={12} />}
        label="Beat"
        value={reporter.beat}
      />

      <Item
        icon={<MapPinned size={12} />}
        label="Coverage"
        value={reporter.coverageArea}
      />

      <Item
        icon={<GraduationCap size={12} />}
        label="Qualification"
        value={reporter.qualification}
      />

      <Item
        icon={<Briefcase size={12} />}
        label="Experience"
        value={
          reporter.experience != null
            ? `${reporter.experience} Years`
            : "-"
        }
      />
    </div>
  );
}