"use client";

import { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export default function CardContainer({ children }: Props) {
  return (
    <div
      className="
        id-card
        relative
        overflow-hidden
        rounded-[3.18mm]
        bg-white
        shadow-xl
        print:shadow-none
      "
      style={{
        width: "85.6mm",
        height: "53.98mm",
      }}
    >
      {children}
    </div>
  );
}