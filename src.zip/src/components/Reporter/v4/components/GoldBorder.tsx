"use client";

export default function GoldBorder() {
  return (
    <>
      <div className="absolute inset-0 rounded-[3.18mm] border-[2px] border-yellow-400" />

      <div className="absolute inset-[3px] rounded-[3mm] border border-yellow-200" />

      {/* Decorative Corners */}

      <div className="absolute left-2 top-2 h-4 w-4 border-l-2 border-t-2 border-yellow-300" />

      <div className="absolute right-2 top-2 h-4 w-4 border-r-2 border-t-2 border-yellow-300" />

      <div className="absolute bottom-2 left-2 h-4 w-4 border-b-2 border-l-2 border-yellow-300" />

      <div className="absolute bottom-2 right-2 h-4 w-4 border-b-2 border-r-2 border-yellow-300" />
    </>
  );
}