"use client";

interface Props {
  authority?: string;
}

export default function Signature({
  authority = "Editor-in-Chief",
}: Props) {
  return (
    <div className="w-36 text-center">
      <div className="mb-4 h-6">
        <div className="text-lg font-script italic text-blue-900">
          {authority}
        </div>
      </div>

      <div className="border-t border-gray-500" />

      <p className="mt-1 text-[7px] font-semibold uppercase text-gray-700">
        Authorized Signature
      </p>
    </div>
  );
}