"use client";

import Image from "next/image";

interface Props {
  photo?: string;
  name: string;
}

export default function ReporterPhoto({
  photo,
  name,
}: Props) {
  return (
    <div className="mx-auto h-20 w-16 overflow-hidden rounded-lg border-2 border-yellow-400 shadow">
      {photo ? (
        <Image
          src={photo}
          alt={name}
          width={160}
          height={200}
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="flex h-full items-center justify-center text-xs font-semibold text-gray-400">
          No Photo
        </div>
      )}
    </div>
  );
}