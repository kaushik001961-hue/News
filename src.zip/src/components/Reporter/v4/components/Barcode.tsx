"use client";

import Barcode from "react-barcode";

interface Props {
  value: string;
}

export default function ReporterBarcode({ value }: Props) {
  return (
    <div className="rounded-md bg-white p-1 shadow-sm">
      <Barcode
        value={value}
        format="CODE128"
        width={1.2}
        height={32}
        displayValue={false}
        margin={0}
        background="#ffffff"
      />
    </div>
  );
}