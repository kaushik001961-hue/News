"use client";

interface Props {
  expiryDate?: string;
}

export default function Footer({
  expiryDate,
}: Props) {
  return (
    <div className="absolute bottom-0 left-0 right-0 h-[3mm] bg-gradient-to-r from-red-900 via-red-700 to-red-900">
      <div className="flex h-full items-center justify-between px-3 text-[5px] font-semibold uppercase tracking-wider text-white">
        <span>AGS NEWS</span>

        <span>
          {expiryDate
            ? `Valid Till ${expiryDate}`
            : "Official Press Identity Card"}
        </span>
      </div>
    </div>
  );
}