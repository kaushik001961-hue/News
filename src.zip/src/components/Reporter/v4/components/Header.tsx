"use client";

import Image from "next/image";

interface HeaderProps {
  logo?: string;
}

export default function Header({
  logo = "/images/ags-news-logo.png",
}: HeaderProps) {
  return (
    <header className="absolute left-0 right-0 top-0 z-20 h-[11mm] px-3 flex items-center justify-between text-white">
      <div className="flex items-center gap-2">
        <Image
          src={logo}
          alt="AGS NEWS"
          width={36}
          height={36}
          priority
          className="h-9 w-9 object-contain rounded-full bg-white p-0.5"
        />

        <div className="leading-none">
          <h1 className="text-[13px] font-extrabold tracking-wide">
            AGS NEWS
          </h1>

          <p className="text-[7px] uppercase tracking-[2px] text-red-100">
            PRESS MEDIA
          </p>
        </div>
      </div>

      <div className="text-right">
        <p className="text-[6px] uppercase tracking-[1.5px]">
          Official Press Card
        </p>

        <div className="mt-1 rounded-full bg-yellow-400 px-2 py-[2px] text-[6px] font-bold text-red-900">
          VERIFIED
        </div>
      </div>
    </header>
  );
}