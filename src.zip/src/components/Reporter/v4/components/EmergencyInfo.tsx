"use client";

import { ReporterCardData } from "../types";

interface Props {
  reporter: ReporterCardData;
}

export default function EmergencyInfo({
  reporter,
}: Props) {
  return (
    <div className="rounded-md border border-red-200 bg-red-50 p-2">
      <h3 className="mb-1 text-[7px] font-bold uppercase text-red-700">
        Emergency Contact
      </h3>

      <div className="space-y-1 text-[6px]">
        <div className="flex justify-between">
          <span className="font-semibold text-gray-600">
            Name
          </span>

          <span className="font-bold">
            {reporter.emergencyName || "-"}
          </span>
        </div>

        <div className="flex justify-between">
          <span className="font-semibold text-gray-600">
            Phone
          </span>

          <span className="font-bold">
            {reporter.emergencyPhone || "-"}
          </span>
        </div>
      </div>
    </div>
  );
}