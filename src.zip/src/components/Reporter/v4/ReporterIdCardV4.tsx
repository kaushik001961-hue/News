import ReporterIdCardFrontV5 from "./ReporterIdCardFrontV5";
import ReporterIdCardBackV5 from "./ReporterIdCardBackV5";
import { ReporterCardData } from "./types";

interface Props {
  reporter: ReporterCardData;
  showBack?: boolean;
  className?: string;
}

export default function ReporterIdCardV5({
  reporter,
  showBack = true,
  className = "",
}: Props) {
  return (
    <div
      className={`
        flex
        flex-wrap
        justify-center
        gap-8
        ${className}
      `}
    >
      {/* Front */}
      <ReporterIdCardFrontV5
        reporter={reporter}
      />

      {/* Back */}
      {showBack && (
        <ReporterIdCardBackV5
          reporter={reporter}
        />
      )}
    </div>
  );
}