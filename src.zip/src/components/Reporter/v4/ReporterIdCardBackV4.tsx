"use client";

import Image from "next/image";
import { Phone, ShieldCheck, UserRound } from "lucide-react";

import { CardSideProps } from "./types";

import Background from "./components/Background";
import CardContainer from "./components/CardContainer";
import GoldBorder from "./components/GoldBorder";
import PrintSafeArea from "./components/PrintSafeArea";
import ReporterDetails from "./components/ReporterDetails";
import ReporterQRCode from "./components/QRCode";
import Signature from "./components/Signature";
import Watermark from "./components/Watermark";

export default function ReporterIdCardBackV4({
  reporter,
}: CardSideProps) {
  return (
    <CardContainer>
      <Background />
      <Watermark />
      <GoldBorder />

      {/* Hologram */}
      <div className="absolute right-3 top-3 h-10 w-10 rounded-full border border-white/60 bg-gradient-to-br from-cyan-300/30 via-violet-300/20 to-yellow-300/30 backdrop-blur-md">
        <div className="absolute inset-1 rounded-full border border-white/40" />
      </div>

      <PrintSafeArea>
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="text-center">
            <Image
              src="/images/ags-news-logo.png"
              alt="AGS NEWS"
              width={42}
              height={42}
              className="mx-auto"
            />

            <h1 className="mt-1 text-lg font-black tracking-widest text-red-800">
              AGS NEWS
            </h1>

            <p className="text-[9px] uppercase tracking-[3px] text-gray-600">
              REPORTER INFORMATION
            </p>

            <div className="mx-auto mt-2 h-[2px] w-40 bg-gradient-to-r from-yellow-500 via-yellow-200 to-yellow-500" />
          </div>

          {/* Details */}
          <div className="mt-3">
            <ReporterDetails reporter={reporter} />
          </div>

          {/* Emergency */}
          <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3">
            <h3 className="mb-2 text-[8px] font-bold uppercase tracking-wide text-red-700">
              Emergency Contact
            </h3>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <UserRound size={12} className="text-red-700" />

                <span className="text-[8px] font-semibold">
                  {reporter.emergencyName || "-"}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Phone size={12} className="text-red-700" />

                <span className="text-[8px] font-semibold">
                  {reporter.emergencyPhone || "-"}
                </span>
              </div>
            </div>
          </div>

          {/* Terms */}
          <div className="mt-3 rounded-lg border border-gray-300 bg-gray-50 p-2">
            <h3 className="mb-1 text-[6px] font-bold uppercase text-gray-700">
              Terms & Conditions
            </h3>

            <ul className="list-disc space-y-[1px] pl-3 text-[5px] text-gray-600">
              <li>This ID card remains the property of AGS NEWS.</li>
              <li>Carry this card while on duty.</li>
              <li>Report loss immediately.</li>
              <li>Misuse will result in cancellation.</li>
            </ul>
          </div>

          {/* Bottom */}
          <div className="mt-auto">
            <div className="flex items-end justify-between">
              <Signature authority={reporter.authority} />

              <ReporterQRCode
                value={
                  reporter.qrCode ??
                  `https://agsnews.in/verify/${reporter.reporterId}`
                }
              />
            </div>

            <div className="mt-3 flex items-center justify-center gap-2 rounded-full bg-green-100 py-1">
              <ShieldCheck size={14} className="text-green-700" />

              <span className="text-[8px] font-bold uppercase tracking-wide text-green-700">
                Scan QR to Verify Reporter
              </span>
            </div>

            <div className="mt-2 rounded bg-gradient-to-r from-red-900 via-red-700 to-red-900 py-1">
              <p className="text-center text-[5px] font-bold uppercase tracking-[2px] text-white">
                AGS NEWS • OFFICIAL PRESS • VERIFIED REPORTER
              </p>
            </div>
          </div>
        </div>
      </PrintSafeArea>
    </CardContainer>
  );
}