import { redirect } from "next/navigation";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import NewsForm from "@/components/news/NewsForm";
import { createNews } from "@/actions/news/create-news";

export default async function CreateEditorNewsPage() {
  const session = await auth();

  if (!session?.user) {
    redirect("/login");
  }

  if (session.user.role !== "EDITOR") {
    redirect("/");
  }

  const categories = await prisma.category.findMany({
    orderBy: {
      name: "asc",
    },
  });

  const reporters = await prisma.reporter.findMany({
    where: {
      status: "APPROVED",
      active: true,
    },
    orderBy: {
      firstName: "asc",
    },
  });

  return (
    <NewsForm
      role="EDITOR"
      mode="create"
      categories={categories}
      reporters={reporters}
      onSubmit={createNews}
    />
  );
}