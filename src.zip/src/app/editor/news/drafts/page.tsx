import { redirect } from "next/navigation";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import NewsTable from "@/components/editor/news/NewsTable";
import NewsStats from "@/components/editor/news/NewsStats";
import NewsToolbar from "@/components/editor/news/NewsToolbar";
import NewsFilters from "@/components/editor/news/NewsFilters";
import NewsPagination from "@/components/editor/news/NewsPagination";

export default async function DraftNewsPage() {
  const session = await auth();

  if (!session?.user) {
    redirect("/login");
  }

  const news = await prisma.post.findMany({
    where: {
      status: "DRAFT",
    },

    include: {
      category: true,
      reporter: true,
    },

    orderBy: {
      updatedAt: "desc",
    },
  });

  return (
    <div className="space-y-8">

      {/* Header */}

      <div>

        <h1 className="text-4xl font-black text-slate-900">
          Draft News
        </h1>

        <p className="mt-2 text-slate-500">
          Manage unpublished draft articles.
        </p>

      </div>

      <NewsStats />

      <NewsToolbar />

      <NewsFilters />

      <NewsTable news={news} />

      <NewsPagination />

    </div>
  );
}