import { prisma } from "@/lib/prisma";
import { getNews } from "@/lib/news-query";

import StatsCards from "@/components/editor/dashboard/StatsCards";
import NewsTable from "@/components/news/table/NewsTable";
import NewsTableClient from "@/components/news/table/NewsTableClient";

interface Props {
  searchParams: {
    page?: string;
    search?: string;
    status?: string;
    category?: string;
    reporter?: string;
    sort?: string;
    date?: string;
  };
}

export default async function EditorNewsPage({
  searchParams,
}: Props) {
  const page = Number(searchParams.page ?? "1");

  const search = searchParams.search ?? "";
  const status = searchParams.status ?? "";
  const category = searchParams.category ?? "";
  const reporter = searchParams.reporter ?? "";
  const sort = searchParams.sort ?? "latest";
  const date = searchParams.date ?? "ALL";

  // Fetch News
  const result = await getNews({
    page,
    search,
    status,
    category,
    reporter,
    sort,
    role: "EDITOR",
  });

  const news = result.news;
  const totalNews = result.total;

  // Fetch Categories
  const categories = await prisma.category.findMany({
    orderBy: {
      name: "asc",
    },
  });

  // Fetch Reporters
  const reporters = await prisma.reporter.findMany({
    where: {
      status: "APPROVED",
      active: true,
    },
    orderBy: {
      firstName: "asc",
    },
    select: {
      id: true,
      firstName: true,
      lastName: true,
    },
  });

  return (
    <div className="space-y-6">
      <StatsCards />

      <NewsTableClient
        total={totalNews}
        createUrl="/editor/news/create"
        categories={categories}
        reporters={reporters}
      >
        <NewsTable news={news} />
      </NewsTableClient>
    </div>
  );
}