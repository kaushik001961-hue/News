import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generateReporterId } from "@/lib/reporterId";

interface Props {
  params: {
    id: string;
  };
}

export async function PATCH(
  request: Request,
  { params }: Props
) {
  try {
    const reporter = await prisma.reporter.findUnique({
      where: {
        id: params.id,
      },
    });

    if (!reporter) {
      return NextResponse.json(
        { error: "Reporter not found" },
        { status: 404 }
      );
    }

    const reporterId = await generateReporterId();

    await prisma.reporter.update({
      where: {
        id: params.id,
      },
      data: {
        status: "APPROVED",
        reporterId,
        approvedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      reporterId,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Unable to approve reporter" },
      { status: 500 }
    );
  }
}