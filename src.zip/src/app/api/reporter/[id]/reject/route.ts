import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

interface Props {
  params: {
    id: string;
  };
}

export async function PATCH(
  request: Request,
  { params }: Props
) {
  try {
    const body = await request.json();

    await prisma.reporter.update({
      where: {
        id: params.id,
      },
      data: {
        status: "REJECTED",
        rejectReason: body.reason,
        rejectedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Unable to reject reporter" },
      { status: 500 }
    );
  }
}