"use client";

import ChangePasswordCard from "@/components/reporter/settings/ChangePasswordCard";
import NotificationPreferencesCard from "@/components/reporter/settings/NotificationPreferencesCard";
import {
  Settings,
  Lock,
  Bell,
} from "lucide-react";

export default function ReporterSettingsPage() {
  return (
    <div className="space-y-8">

      {/* Header */}
      <div className="rounded-2xl border bg-white p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-blue-100">
            <Settings className="h-7 w-7 text-blue-600" />
          </div>

          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Settings
            </h1>

            <p className="mt-1 text-gray-500">
              Manage your account password and notification preferences.
            </p>
          </div>
        </div>
      </div>

      {/* Security */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Lock className="h-5 w-5 text-blue-600" />

          <h2 className="text-xl font-semibold">
            Security
          </h2>
        </div>

        <ChangePasswordCard />
      </section>

      {/* Notifications */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-amber-500" />

          <h2 className="text-xl font-semibold">
            Notification Preferences
          </h2>
        </div>

        <NotificationPreferencesCard />
      </section>

    </div>
  );
}