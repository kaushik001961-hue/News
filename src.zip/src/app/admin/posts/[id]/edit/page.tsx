import { prisma } from "@/lib/prisma";
import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import React from "react";

type Params = Promise<{ id: string }>;

interface EditPostPageProps {
  params: Params;
}

export default async function EditPostPage({ params }: EditPostPageProps) {
  const { id } = await params;

  // 1. Fetch the post and available categories
  const [post, categories] = await Promise.all([
    prisma.post.findUnique({
      where: { id },
    }),
    prisma.category.findMany(),
  ]);

  if (!post) {
    notFound();
  }

  // 2. Server Action processing form elements + uploads + toggles + status flags
  async function updatePostAction(formData: FormData) {
    "use server";

    const title = formData.get("title") as string;
    const categoryId = formData.get("category") as string; 
    const content = formData.get("content") as string;
    const imageFile = formData.get("image") as File;

    const isBreaking = formData.get("isBreaking") === "on";
    const isFeatured = formData.get("isFeatured") === "on";
    
    // 🚀 READ STATUS: Captures whether the admin selected "PUBLISHED" or "DRAFT"
    const statusValue = formData.get("status") as string; 
    const isPublishedBoolean = statusValue === "PUBLISHED";

    let imageUrl = post.imageUrl || (post as any).image || (post as any).coverImage || "";

    if (imageFile && imageFile.size > 0 && imageFile.name !== "undefined") {
      try {
        const buffer = Buffer.from(await imageFile.arrayBuffer());
        imageUrl = `data:${imageFile.type};base64,${buffer.toString("base64")}`;
      } catch (err) {
        console.error("❌ Failed to process image file buffer:", err);
      }
    }

    const imageKey = "imageUrl" in post ? "imageUrl" : "image" in post ? "image" : "coverImage";

    // Update record in database
    await prisma.post.update({
      where: { id },
      data: {
        title,
        content,
        [imageKey]: imageUrl,
        ...("isBreaking" in post ? { isBreaking } : "breaking" in post ? { breaking: isBreaking } : {}),
        ...("isFeatured" in post ? { isFeatured } : "featured" in post ? { featured: isFeatured } : {}),
        
        // 🚀 DYNAMIC STATUS COUPLING: Maps correctly whether your DB uses an Enum String or a Boolean flag
        ...("status" in post ? { status: statusValue } : "isPublished" in post ? { isPublished: isPublishedBoolean } : "published" in post ? { published: isPublishedBoolean } : {}),
        
        category: {
          connect: { id: categoryId }
        }
      },
    });

    redirect("/admin/posts");
  }

  // Fallbacks to determine checked configurations
  const currentBreaking = (post as any).isBreaking || (post as any).breaking || false;
  const currentFeatured = (post as any).isFeatured || (post as any).featured || false;
  
  // Resolve current database status to string representation ("PUBLISHED" vs "DRAFT")
  const currentStatus = (post as any).status 
    ? (post as any).status 
    : ((post as any).isPublished || (post as any).published) ? "PUBLISHED" : "DRAFT";

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto space-y-6 w-full overflow-x-hidden">
      
      {/* --- Breadcrumb Header Navigation --- */}
      <div className="space-y-1">
        <div className="text-xs text-neutral-400 font-medium tracking-wide uppercase flex items-center gap-1.5">
          <span>Admin</span>
          <span>/</span>
          <span>Posts</span>
          <span>/</span>
          <span className="text-neutral-600">Edit</span>
        </div>
        <h1 className="text-2xl md:text-3xl font-black text-neutral-900 tracking-tight">
          Edit Post Details
        </h1>
      </div>

      {/* --- Main Edit Form Interface --- */}
      <form 
        action={updatePostAction} 
        className="bg-white p-5 md:p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-5"
      >
        
        {/* Input Field: Post Title */}
        <div className="space-y-1.5">
          <label className="block text-sm font-bold text-neutral-700 tracking-wide">
            Post Title
          </label>
          <input
            type="text"
            name="title"
            defaultValue={post.title}
            className="w-full px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-neutral-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>

        {/* Input Field: Category Selector */}
        <div className="space-y-1.5">
          <label className="block text-sm font-bold text-neutral-700 tracking-wide">
            Category
          </label>
          <select 
            name="category"
            defaultValue={post.categoryId || ""}
            className="w-full px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-neutral-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
          >
            <option value="" disabled>Select a category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>
        </div>

        {/* 🚀 NEW: Publication Status Selector (Draft vs Published) */}
        <div className="space-y-1.5">
          <label className="block text-sm font-bold text-neutral-700 tracking-wide">
            Publication Status
          </label>
          <select 
            name="status"
            defaultValue={currentStatus}
            className="w-full px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-neutral-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition font-medium"
          >
            <option value="DRAFT">📁 Save as Draft (Hidden from public)</option>
            <option value="PUBLISHED">🚀 Publish Live (Visible to everyone)</option>
          </select>
        </div>

        {/* Badges / Visibility Flag Layout Switches */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-neutral-50 p-4 rounded-xl border border-neutral-200">
          
          {/* Toggle: Breaking News */}
          <label className="flex items-center space-x-3 cursor-pointer select-none">
            <input 
              type="checkbox" 
              name="isBreaking" 
              defaultChecked={currentBreaking}
              className="w-5 h-5 rounded text-red-600 border-neutral-300 focus:ring-red-500 transition cursor-pointer"
            />
            <div>
              <span className="block text-sm font-bold text-neutral-800">Breaking News</span>
              <span className="block text-xs text-neutral-400">Flash story on home headline</span>
            </div>
          </label>

          {/* Toggle: Featured News */}
          <label className="flex items-center space-x-3 cursor-pointer select-none">
            <input 
              type="checkbox" 
              name="isFeatured" 
              defaultChecked={currentFeatured}
              className="w-5 h-5 rounded text-blue-600 border-neutral-300 focus:ring-blue-500 transition cursor-pointer"
            />
            <div>
              <span className="block text-sm font-bold text-neutral-800">Featured Post</span>
              <span className="block text-xs text-neutral-400">Pin story inside sidebars</span>
            </div>
          </label>

        </div>

        {/* Post Cover Image Upload Field */}
        <div className="space-y-1.5">
          <label className="block text-sm font-bold text-neutral-700 tracking-wide">
            Cover Image
          </label>
          {(post.imageUrl || (post as any).image) && (
            <div className="mb-2 text-xs text-neutral-500 flex items-center gap-2">
              <span>Current Image:</span>
              <div className="w-12 h-12 rounded bg-gray-100 overflow-hidden border">
                <img 
                  src={post.imageUrl || (post as any).image} 
                  alt="Preview" 
                  className="w-full h-full object-cover" 
                />
              </div>
            </div>
          )}
          <input
            type="file"
            name="image"
            accept="image/*"
            className="w-full text-sm text-neutral-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
          />
        </div>

        {/* Text Area Field: Content Editor Body */}
        <div className="space-y-1.5">
          <label className="block text-sm font-bold text-neutral-700 tracking-wide">
            Content Body
          </label>
          <textarea
            name="content"
            defaultValue={post.content}
            className="w-full px-4 py-2.5 bg-neutral-50 border border-neutral-200 rounded-xl text-neutral-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition h-64 resize-y"
          />
        </div>

        {/* --- Form Footer Actions Layout --- */}
        <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 pt-2">
          <Link
            href="/admin/posts"
            className="w-full sm:w-auto px-5 py-2.5 border border-neutral-200 text-neutral-700 font-semibold rounded-xl hover:bg-neutral-50 text-sm transition text-center block"
          >
            Cancel
          </Link>
          <button
            type="submit"
            className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-sm transition"
          >
            Update Post
          </button>
        </div>

      </form>
    </div>
  );
}