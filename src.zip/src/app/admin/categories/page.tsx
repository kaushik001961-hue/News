import { prisma } from "@/lib/prisma";
import CategoryStats from "@/components/admin/categories/CategoryStats";
import CategoriesClient from "./CategoriesClient";

export default async function CategoriesPage() {

  const [
    total,
    active,
    inactive,
    totalNews,
    categories,
  ] = await Promise.all([

    prisma.category.count(),

    prisma.category.count({
      where: {
        active: true,
      },
    }),

    prisma.category.count({
      where: {
        active: false,
      },
    }),

    prisma.post.count(),

    prisma.category.findMany({
      include: {
        _count: {
          select: {
            posts: true,
          },
        },
      },
    }),

  ]);

  return (
    <>
      <CategoryStats
        total={total}
        active={active}
        inactive={inactive}
        totalNews={totalNews}
      />

      <CategoriesClient
        categories={categories}
      />
    </>
  );
}