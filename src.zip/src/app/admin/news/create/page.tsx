"use server";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { revalidatePath } from "next/cache";

export interface UpdateNewsInput {
  id: string;

  title: string;
  slug: string;

  excerpt?: string;
  content: string;

  categoryId?: string;
  reporterId?: string;

  featuredImage?: string;
  videoUrl?: string;

  featured: boolean;
  breaking: boolean;
  trending: boolean;

  seoTitle?: string;
  seoDescription?: string;
  keywords?: string;
  canonicalUrl?: string;

  status: string;
}

export async function updateNews(
  values: UpdateNewsInput
) {
  const session = await auth();

  if (!session?.user) {
    throw new Error("Unauthorized");
  }

  const role = session.user.role;

  const data: any = {
    title: values.title,
    slug: values.slug,

    excerpt: values.excerpt,
    content: values.content,

    image: values.featuredImage || null,
    video: values.videoUrl || null,

    categoryId:
      values.categoryId || null,

    featured: values.featured,
    breaking: values.breaking,
    trending: values.trending,

    seoTitle: values.seoTitle,
    seoDescription:
      values.seoDescription,
    seoKeywords: values.keywords,
    canonicalUrl:
      values.canonicalUrl,
  };

  if (
    role === "EDITOR" ||
    role === "ADMIN"
  ) {
    data.status = values.status;

    data.assignedReporterId =
      values.reporterId || null;
  }

  await prisma.post.update({
    where: {
      id: values.id,
    },
    data,
  });

  revalidatePath("/");

  revalidatePath("/admin/news");

  revalidatePath("/editor/news");

  revalidatePath("/reporter/news");
}