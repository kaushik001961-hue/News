export default function SettingsPage() {
  return (
    <div className="rounded-2xl bg-white p-8 shadow">
      <h1 className="text-3xl font-bold text-slate-900">
        Settings
      </h1>

      <p className="mt-3 text-slate-600">
        Configure your News CMS settings here.
      </p>
    </div>
  );
}