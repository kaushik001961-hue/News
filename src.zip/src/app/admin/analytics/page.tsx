export default function AnalyticsPage() {
  return (
    <div className="rounded-2xl bg-white p-8 shadow">
      <h1 className="text-3xl font-bold">Analytics</h1>
      <p className="mt-2 text-slate-500">
        Analytics dashboard coming soon.
      </p>
    </div>
  );
}