"use client";

import type { ReporterCardData } from "./ReporterIdCardV2";

interface Props {
  reporter: ReporterCardData;
}

export default function ReporterIdCardBackV2({ reporter }: Props) {
  return (
    <div
      style={{
        width: "86mm",
        height: "54mm",
        borderRadius: "18px",
        background: "#0A4D9C",
        color: "#fff",
        padding: "16px",
      }}
    >
      <h2>AGS NEWS</h2>

      <p>
        {reporter.firstName} {reporter.lastName}
      </p>

      <p>Status: {reporter.status}</p>

      <p>
        Card: {reporter.PressCard?.cardNumber ?? "Pending"}
      </p>
    </div>
  );
}