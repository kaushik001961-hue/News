"use client";

import CardBackground from "./components/CardBackground";
import CardHeader from "./components/CardHeader";
import PressBanner from "./components/PressBanner";
import PhotoSection from "./components/PhotoSection";
import ReporterDetails from "./components/ReporterDetails";
import QRSection from "./components/QRSection";
import CardFooter from "./components/CardFooter";
import SecurityBorder from "./components/SecurityBorder";

import type { ReporterCardData } from "./ReporterIdCardV2";

interface Props {
  reporter: ReporterCardData;
}

export default function ReporterIdCardFrontV2({
  reporter,
}: Props) {
  const qrValue = `${process.env.NEXT_PUBLIC_APP_URL}/verify/${
    reporter.PressCard?.cardNumber ??
    reporter.reporterId
  }`;

  return (
    <div
      className="relative overflow-hidden rounded-[22px] shadow-2xl"
      style={{
        width: "54mm",
        height: "86mm",
      }}
    >
      {/* Background */}

      <CardBackground />

      {/* Header */}

      <CardHeader />

      {/* PRESS Banner */}

      <PressBanner />

      {/* Reporter Photo */}

      <PhotoSection
        reporter={reporter}
      />

      {/* Reporter Details */}

      <ReporterDetails
        reporter={reporter}
      />
            {/* QR Section */}

      <div className="absolute left-0 right-0 bottom-24">

        <QRSection
          qrValue={qrValue}
        />

      </div>

      {/* Footer */}

      <CardFooter
        status={reporter.status}
      />

      {/* Premium Border */}

      <SecurityBorder />

      {/* Glass Reflection */}

      <div
        className="
          pointer-events-none
          absolute
          inset-0
          opacity-15
        "
      >
        <div
          className="
            absolute
            -left-24
            top-10
            h-[180px]
            w-[120px]
            rotate-[-28deg]
            bg-white/30
            blur-2xl
          "
        />

        <div
          className="
            absolute
            right-[-60px]
            bottom-16
            h-40
            w-20
            rotate-[25deg]
            bg-white/10
            blur-3xl
          "
        />

      </div>

      {/* Top Decorative Rings */}

      <div className="pointer-events-none absolute right-3 top-24">

        <div className="h-16 w-16 rounded-full border border-white/10" />

        <div className="absolute left-2 top-2 h-12 w-12 rounded-full border border-white/10" />

      </div>

      {/* Bottom Decorative Rings */}

      <div className="pointer-events-none absolute bottom-20 left-3">

        <div className="h-14 w-14 rounded-full border border-white/10" />

        <div className="absolute left-2 top-2 h-10 w-10 rounded-full border border-white/10" />

      </div>