"use client";

import React from "react";

interface Props {
  front: React.ReactNode;
  back: React.ReactNode;
}

export default function PrintLayout({
  front,
  back,
}: Props) {
  return (
    <>
      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            background: #ffffff !important;
            margin: 0;
            padding: 0;
          }

          .no-print {
            display: none !important;
          }

          .print-page {
            width: 210mm;
            height: 297mm;
            margin: 0;
            padding: 12mm;
            page-break-after: always;
            background: white;
          }

          .print-card {
            break-inside: avoid;
          }
        }
      `}</style>

      <div className="print-page mx-auto max-w-[1100px] rounded-3xl bg-white p-8 shadow-xl">

        {/* Title */}

        <div className="no-print mb-8 text-center">

          <h2 className="text-3xl font-black text-slate-900">
            AGS NEWS Press Card
          </h2>

          <p className="mt-2 text-slate-500">
            Professional PVC Card Print Layout (CR80 • 86 × 54 mm)
          </p>

        </div>

        {/* Cards */}

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">

          {/* FRONT */}

          <section className="flex flex-col items-center">

            <div className="mb-4 text-xs font-bold uppercase tracking-[0.35em] text-slate-500">
              Front Side
            </div>

            <CropMarks>
              <div className="print-card">
                {front}
              </div>
            </CropMarks>

          </section>

          {/* BACK */}

          <section className="flex flex-col items-center">

            <div className="mb-4 text-xs font-bold uppercase tracking-[0.35em] text-slate-500">
              Back Side
            </div>

            <CropMarks>
              <div className="print-card">
                {back}
              </div>
            </CropMarks>

          </section>

        </div>

        {/* Print Notes */}

        <div className="no-print mt-10 rounded-2xl border border-slate-200 bg-slate-50 p-6">

          <h3 className="mb-3 text-lg font-bold">
            Printing Instructions
          </h3>

          <ul className="space-y-2 text-sm text-slate-600">

            <li>• Card Size: CR80 (86 × 54 mm)</li>

            <li>• Recommended Material: PVC</li>

            <li>• Print Resolution: 300 DPI or higher</li>

            <li>• Lamination: Gloss or Matte Finish</li>

            <li>• Keep crop marks outside the final trim area.</li>

          </ul>

        </div>

      </div>
    </>
  );
}

function CropMarks({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="relative inline-block p-5">

      {/* Top Left */}

      <span className="absolute left-0 top-0 h-5 w-[2px] bg-black" />
      <span className="absolute left-0 top-0 h-[2px] w-5 bg-black" />

      {/* Top Right */}

      <span className="absolute right-0 top-0 h-5 w-[2px] bg-black" />
      <span className="absolute right-0 top-0 h-[2px] w-5 bg-black" />

      {/* Bottom Left */}

      <span className="absolute bottom-0 left-0 h-5 w-[2px] bg-black" />
      <span className="absolute bottom-0 left-0 h-[2px] w-5 bg-black" />

      {/* Bottom Right */}

      <span className="absolute bottom-0 right-0 h-5 w-[2px] bg-black" />
      <span className="absolute bottom-0 right-0 h-[2px] w-5 bg-black" />

      {children}

    </div>
  );
}