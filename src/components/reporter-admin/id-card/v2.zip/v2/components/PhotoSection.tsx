"use client";

import Image from "next/image";
import type { ReporterCardData } from "../ReporterIdCardV2";

interface Props {
  reporter: ReporterCardData;
}

export default function PhotoSection({ reporter }: Props) {
  return (
    <div className="relative z-20 mt-4 flex justify-center">

      <div className="relative">

        {/* White Frame */}

        <div className="rounded-2xl bg-white p-1 shadow-2xl">

          <div className="relative h-40 w-32 overflow-hidden rounded-xl bg-slate-200">

            <Image
              src={
                reporter.photo ||
                "/images/avatar-placeholder.png"
              }
              alt={reporter.firstName}
              fill
              className="object-cover"
            />

          </div>

        </div>

        {/* VERIFIED Badge */}

        <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-green-600 px-3 py-1 shadow-lg">

          <span className="text-[9px] font-bold tracking-[0.15em] text-white">
            VERIFIED
          </span>

        </div>

      </div>

    </div>
  );
}