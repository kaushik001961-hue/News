"use client";

import type { ReporterCardData } from "../ReporterIdCardV2";

interface Props {
  reporter: ReporterCardData;
}

function Row({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between border-b border-white/20 py-1">

      <span className="text-[8px] font-semibold uppercase tracking-[0.20em] text-red-100">
        {label}
      </span>

      <span className="text-[10px] font-bold text-white">
        {value}
      </span>

    </div>
  );
}

export default function ReporterDetails({
  reporter,
}: Props) {
  return (
    <div className="relative z-20 mt-6 px-5">

      {/* Name */}

      <div className="text-center">

        <h2 className="text-xl font-black uppercase tracking-wide text-white">
          {reporter.firstName} {reporter.lastName}
        </h2>

        <div className="mt-2 inline-flex rounded-full bg-white px-4 py-1 shadow">

          <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-red-700">
            {reporter.designation || "Reporter"}
          </span>

        </div>

      </div>

      {/* Details */}

      <div className="mt-5 rounded-2xl bg-white/10 p-3 backdrop-blur-md">

        <Row
          label="Reporter ID"
          value={reporter.reporterId}
        />

        <Row
          label="Card No"
          value={
            reporter.PressCard?.cardNumber ||
            "Pending"
          }
        />

        <Row
          label="Blood"
          value={reporter.bloodGroup || "-"}
        />

        <Row
          label="Phone"
          value={reporter.phone || "-"}
        />

        <Row
          label="District"
          value={reporter.district || "-"}
        />

        <Row
          label="State"
          value={reporter.state || "-"}
        />

        <Row
          label="Valid Till"
          value={
            reporter.PressCard?.expiryDate
              ? new Date(
                  reporter.PressCard.expiryDate
                ).toLocaleDateString("en-GB")
              : "--"
          }
        />

      </div>

    </div>
  );
}