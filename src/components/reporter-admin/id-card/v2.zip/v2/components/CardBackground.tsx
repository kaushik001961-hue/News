"use client";

export default function CardBackground() {
  return (
    <>
      {/* Main Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-red-700 via-red-600 to-red-800" />

      {/* Top Glow */}
      <div className="absolute -top-24 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-red-300/20 blur-3xl" />

      {/* Bottom Glow */}
      <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-red-900/40 blur-3xl" />

      {/* Right Glow */}
      <div className="absolute -right-16 top-32 h-40 w-40 rounded-full bg-yellow-300/10 blur-3xl" />

      {/* World Map */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: "url('/images/world-map.png')",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          backgroundSize: "92%",
        }}
      />

      {/* Diagonal Shine */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          background:
            "linear-gradient(135deg,transparent 25%,rgba(255,255,255,.35) 50%,transparent 75%)",
        }}
      />

      {/* Decorative Circles */}
      <div className="absolute right-3 top-28 h-24 w-24 rounded-full border border-white/10" />
      <div className="absolute left-4 bottom-28 h-16 w-16 rounded-full border border-white/10" />
    </>
  );
}