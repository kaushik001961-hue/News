"use client";

import Image from "next/image";
import ReporterHologram from "../../ReporterHologram";

export default function CardHeader() {
  return (
    <div className="relative z-20 bg-white px-4 py-3">

      <div className="flex items-center justify-between">

        <div className="flex items-center gap-3">

          <div className="relative h-12 w-12">

            <Image
              src="/logo.png"
              alt="AGS NEWS"
              fill
              className="object-contain"
            />

          </div>

          <div>

            <h1 className="text-lg font-black tracking-[0.28em] text-red-700">
              AGS NEWS
            </h1>

            <p className="text-[8px] font-semibold uppercase tracking-[0.30em] text-slate-500">
              PRESS IDENTIFICATION CARD
            </p>

          </div>

        </div>

        <ReporterHologram />

      </div>

    </div>
  );
}