"use client";

import ReporterQRCode from "../../ReporterQRCode";
import ReporterSeal from "../../ReporterSeal";
import ReporterSignature from "../../ReporterSignature";

interface Props {
  qrValue: string;
}

export default function QRSection({
  qrValue,
}: Props) {
  return (
    <div className="relative z-20 mt-5 px-5">

      <div className="flex items-end justify-between">

        {/* QR */}

        <div className="rounded-xl bg-white p-2 shadow-xl">

          <ReporterQRCode
            value={qrValue}
            size={64}
          />

        </div>

        {/* Signature */}

        <div className="flex flex-col items-end">

          <ReporterSignature />

          <div className="mt-2">

            <ReporterSeal />

          </div>

        </div>

      </div>

    </div>
  );
}