"use client";

import StatusBadge from "./StatusBadge";

interface Props {
  status?: string | null;
}

export default function CardFooter({
  status,
}: Props) {
  return (
    <div className="absolute bottom-0 left-0 right-0 z-20">

      {/* White Section */}

      <div className="bg-white px-4 py-2">

        <div className="flex items-center justify-between">

          <div>

            <p className="text-[7px] font-bold uppercase tracking-[0.30em] text-red-700">
              Authorized Press Credential
            </p>

            <p className="mt-1 text-[7px] text-slate-500">
              Property of AGS NEWS
            </p>

          </div>

          <StatusBadge
            status={status}
          />

        </div>

      </div>

      {/* Bottom Strip */}

      <div className="bg-red-800 px-4 py-2 text-center">

        <p className="text-[7px] font-bold tracking-[0.30em] text-white">
          WWW.AGSNEWS.IN
        </p>

        <p className="mt-1 text-[6px] text-red-100">
          PRESS • MEDIA • DIGITAL
        </p>

      </div>

    </div>
  );
}